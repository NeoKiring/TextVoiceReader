# User Guide

## 画面構成

右側の設定パネルはスクロールできます。ウィンドウの高さが不足する場合でも、音声設定・出力設定・Outlook 設定を縦スクロールで確認できます。


```
┌────────────────────────────────────────────────────────┐
│  TextVoiceReader                                       │
├────────────────────────────────────────────────────────┤
│ [📂 ファイルを開く] [📋 クリップボード] [🗑 クリア]     │
├──────────────────────┬─────────────────────────────────┤
│                      │  🔊 音声設定                    │
│  テキストプレビュー  │  Voice: [Haruka       ▼]       │
│  （編集可能）        │  Speed: [ ──●── ]  0           │
│                      │  Volume:[ ────● ] 80           │
│  読み上げ中の文を    │  Pitch: [ ──●── ]  0           │
│  青くハイライト      │                                 │
│                      │  📁 出力                        │
│                      │  ☑ 再生  ☑ WAV保存             │
│                      │  保存先: [...] [選択]           │
├──────────────────────┴─────────────────────────────────┤
│ [▶ 読み上げ] [⏹ 停止] [▶ 再生] [⏹] ██████░░ 34/120 │
├────────────────────────────────────────────────────────┤
│ [▾ ログ] 折りたたみ式のログ表示                        │
└────────────────────────────────────────────────────────┘
```

## 基本操作

### ファイルを読み込んで再生
1. **📂 ファイルを開く** をクリックし、対象ファイルを選択
2. 自動でテキストが抽出・分割・プレビューに表示されます
3. 右パネルで Voice（音声）を選択、Speed/Volume/Pitch を調整
4. 出力設定（再生 / WAV保存）を確認
5. 上部ツールバーの **▶ 読み上げ**、または下部操作バーの **▶ 再生** ボタン
6. 中断したい場合は **⏹ 停止** を使用

### クリップボードから読み込む
1. 他のアプリでテキストをコピー (Ctrl+C)
2. **📋 クリップボード** をクリック

### テキストを直接編集
プレビューエリアは編集可能です。編集後、上部ツールバーの **▶ 読み上げ** または下部操作バーの **▶ 再生** を押すと、編集後のテキストで再処理されます。

## 音声設定

| 項目 | 範囲 | 説明 |
|------|------|------|
| Voice | — | インストール済み SAPI5 音声の一覧。「音声一覧を更新」で再読込。 |
| Speed | -10 ～ +10 | 話速。0 が標準速度。+10 で約2倍速、-10 で約半速。 |
| Volume | 0 ～ 100 | 音量。0 で無音、100 で最大。 |
| Pitch | -10 ～ +10 | ピッチ（声の高さ）。0 で標準。SSML `<prosody pitch>` 経由で適用。 |

**Voiceが少ない場合**:
Windows 設定 → 時刻と言語 → 言語と地域 → 日本語 → オプション → テキスト読み上げをインストール
で Haruka / Ayumi 等を追加できます。

## 出力モード

| 再生 | WAV保存 | 挙動 |
|:----:|:-------:|------|
| ☑ | ☐ | 再生のみ（高速） |
| ☐ | ☑ | ファイル出力のみ（バックグラウンド処理向き） |
| ☑ | ☑ | 再生 + 同じ内容の WAV を保存（推奨） |

出力 WAV のファイル名は `<入力ファイル名>_YYYYMMDD_HHMMSS.wav` です。

## 設定ファイル

設定の永続化は 3 層で行われます。

| 優先度 | 場所 | 用途 |
|:------:|-----|------|
| 低 | パッケージ同梱の `default.toml` | 同梱デフォルト |
| 中 | `%APPDATA%\TextVoiceReader\config.toml` | ユーザー設定（GUIで保存可） |
| 高 | `TVR_*` 環境変数 | CI/バッチ用の上書き |

環境変数の例:

```powershell
$env:TVR_TTS__VOICE = "Microsoft Haruka Desktop"
$env:TVR_TTS__RATE = "2"
$env:TVR_OUTPUT__SAVE_DIR = "D:\tts_output"
python -m text_voice_reader
```

## CLI コマンド リファレンス

```
python -m text_voice_reader [OPTIONS]

OPTIONS:
  --file, -f PATH      入力ファイル (.txt/.md/.pdf/.docx/.pptx/.html/.csv/.msg)
  --text, -t TEXT      直接テキストを指定
  --out, -o PATH       出力 WAV ファイル（config.save_dir を上書き）
  --voice, -v NAME     音声名 / ID の部分一致
  --rate INT           話速 -10..+10
  --volume INT         音量 0..100
  --pitch INT          ピッチ -10..+10
  --no-gui             CLIモード
  --no-play            再生を無効化
  --no-save            WAV保存を無効化
  --list-voices        インストール済み音声を列挙して終了
  --version            バージョン表示
```

### よく使う例

```powershell
# GUI 起動
python -m text_voice_reader

# Markdown を WAV にするだけ
python -m text_voice_reader --file README.md --no-gui --no-play --out readme.wav

# 直接テキストを Haruka で高速読み上げ
python -m text_voice_reader --text "こんにちは" --voice Haruka --rate 5 --no-gui

# バッチ処理（フォルダ内全txtをwav化）
Get-ChildItem *.txt | ForEach-Object {
    python -m text_voice_reader --file $_.FullName --no-gui --no-play
}
```

CLI 完了時は `success=<件数> failed=<件数> total=<件数>` を標準エラーへ出力します。
失敗が 1 件でもあれば終了コードは非 0 です。

## トラブルシューティング

| 症状 | 対処 |
|------|------|
| 「SAPI5 is only available on Windows」 | 本アプリは Windows 専用です |
| 「pywin32 is not installed」 | `pip install pywin32` |
| 日本語音声が出ない | Windows の言語設定で日本語の「テキスト読み上げ」を追加 |
| 一時停止したい | 現在は未対応です。⏹ 停止 → ▶ 読み上げ / ▶ 再生で対応 |
| 長いPDFで最初の合成が重い | 初回は SAPI5 が音声キャッシュを作るため。2回目以降は高速化 |
| WAVが途切れる | サンプリングレートを 44100 にしてみる (`output.wav_sample_rate = 44100`) |

## キーボードショートカット

現バージョンでは未実装です。将来の拡張予定。

## ログ

- 表示: 画面下部の **▸ ログ** をクリック（折り畳み解除）
- ファイル: `%APPDATA%\TextVoiceReader\logs\TextVoiceReader.log`
  - 10MB ごとにローテート、14日間保持

## Outlook 新着メール読み上げ

この機能は classic Outlook for Windows 向けです。new Outlook for Windows / Outlook Web / Microsoft Graph 連携には対応していません。

1. classic Outlook を起動します。
2. TextVoiceReader を起動します。
3. 右側の設定パネルにある「Outlook」セクションで「新着メールを読み上げる」を ON にします。
4. 必要に応じて「今すぐチェック」を押します。
5. 新着メールが検出されると、差出人・件名・本文冒頭が読み上げられます。
6. 本文冒頭の読み上げ後、「このメールの本文全文を読み上げますか？」と表示されます。
7. Yes を選ぶと全文を読み上げます。No を選ぶと本文全文は読み上げません。

注意:

- Outlook 連携は初期状態では OFF です。
- メール本文はログには出しません。
- Outlook メール読み上げでは、通常の WAV 保存設定に関係なく WAV 保存しません。
- 監視対象は初期実装では Inbox のみです。
