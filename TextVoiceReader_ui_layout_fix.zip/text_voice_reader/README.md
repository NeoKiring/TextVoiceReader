# TextVoiceReader

Windows デスクトップ向け **テキスト読み上げ（TTS）アプリ**です。
TXT / Markdown / PDF / Word / PowerPoint / HTML / CSV / Outlook メール を読み込み、
Windows の **SAPI5 音声合成エンジン**で読み上げ、同時に WAV ファイルへ保存できます。

<p align="center">
  <em>Python 3.11+ / CustomTkinter GUI / Windows SAPI5 (pywin32)</em>
</p>

---

## 主な機能

- **対応入力形式**: `.txt` `.md` `.pdf` `.docx` `.pptx` `.html` `.csv` `.msg`
- **日本語 + 英語** の混在テキストに対応（言語自動判定）
- **再生モード**: アプリ上で即時再生
- **保存モード**: 高品質 WAV ファイルとして書き出し
- **ハイブリッド**: 再生しながら同じ内容を WAV に保存
- **音声設定**: Voice / Speed / Volume / Pitch のリアルタイム調整
- **CLI モード** で自動化（バッチ処理）にも利用可能
- **loguru** による詳細なログ、**pydantic-settings** による型安全な設定

---

## 動作要件

- Windows 10 / 11 (x64)
- Python 3.11 以上
- 日本語音声を使う場合は、Windows 側に日本語 SAPI5 音声がインストールされていること

> 本アプリの本番ターゲットは Windows です。テストや一部処理は他 OS でも動きますが、SAPI5 読み上げは Windows 専用です。

---

## インストール

### 通常インストール

```powershell
pip install .
```

### 開発インストール

```powershell
pip install -e .[dev]
```

### 依存ライブラリが不足した場合

```powershell
pip install -U pywin32 customtkinter loguru pydantic pydantic-settings toml \
    pymupdf python-docx python-pptx beautifulsoup4 Markdown docx2txt \
    extract-msg mecab-python3 unidic-lite langid pyperclip
```

---

## GUI の使い方

```powershell
python -m text_voice_reader
```

### 基本フロー

1. **📂 ファイルを開く** または **📋 クリップボード** でテキストを取り込む
2. 右パネルで **Voice / Speed / Volume / Pitch** を調整
3. 出力設定で **再生** / **WAV保存** を選ぶ
4. 上部ツールバーまたは下部操作バーの **▶ 読み上げ / ▶ 再生** を押す
5. 必要なら **⏹ 停止** で中断する

> 現在の GUI は **ドラッグ&ドロップ非対応** です。ファイルの読み込みは「📂 ファイルを開く」を使用してください。

---

## CLI の使い方

### ファイルを読み上げ

```powershell
python -m text_voice_reader --file sample.txt --no-gui
```

### 再生せず WAV だけ保存

```powershell
python -m text_voice_reader --file sample.txt --no-gui --no-play
```

### テキスト直接指定

```powershell
python -m text_voice_reader --text "こんにちは。これはテストです。" --no-gui
```

### 利用可能音声の一覧

```powershell
python -m text_voice_reader --list-voices
```

CLI 完了時は `success=<件数> failed=<件数> total=<件数>` を標準エラーへ出力します。
一部失敗を含む場合、終了コードは非 0 になります。

---

## 設定ファイル

設定は次の順で読み込まれます（下が優先）:

1. パッケージ同梱のデフォルト設定
2. ユーザー設定 `%APPDATA%/TextVoiceReader/config.toml`
3. 環境変数 `TVR_*`（例: `TVR_TTS__VOICE=Haruka`）

GUI 内の **「⚙ 設定を保存」** で現在値を (2) に書き出せます。

設定例:

```toml
[tts]
engine = "sapi5"
voice = "Microsoft Haruka Desktop"
rate = 0
volume = 90
pitch = 0

[output]
play = true
save_wav = true
save_dir = "~/Documents/TextVoiceReader/out"
wav_sample_rate = 22050

[processing]
split_max_chars = 120
strip_urls = true
```

詳細は [`docs/user_guide.md`](docs/user_guide.md) を参照。

---

## 開発

### テスト

```powershell
pytest -q                    # SAPI5不要テスト + COMモックテスト
pytest -q -m "not sapi5"     # SAPI5を必要としないもののみ（CI向け）
pytest --cov=src/text_voice_reader
```

### Lint / フォーマット

```powershell
ruff check .
ruff format .
black --check .
```

### プロジェクト構成

`docs/architecture.md` に詳細なレイヤー図があります。概略:

```
Presentation (CustomTkinter UI)
    ↓
Application (AppOrchestrator)
    ↓
Domain (Loader / Processor / TtsEngine / AudioSink - Protocol)
    ↓
Infrastructure (SAPI5 via pywin32 / File I/O / winsound)
```

### 新しい Loader / TtsEngine の追加方法

`docs/developer_guide.md` を参照。Loader は `TextLoader` Protocol を、TTS エンジンは `TtsEngine` Protocol を実装し、ファクトリに登録するだけで拡張できます。

---

## FAQ

**Q. 日本語音声が "Microsoft David Desktop" しか出ない**
→ Windows 設定 → 時刻と言語 → 言語と地域 → 日本語 → オプション → テキスト読み上げをインストール、で Haruka 等が追加されます。

**Q. 一時停止が効かない**
→ 現在の GUI は **一時停止ボタンを提供していません**。途中で止める場合は **「⏹ 停止」** を使用してください。

**Q. ONNX モデルは使える？**
→ アーキテクチャ上は対応可能です (`tts.engine = "onnx"` 指定時)。ただし現在はスタブ実装で、モデルの取り込みは Phase 5 の作業項目です。

---

## ライセンス

MIT License — [`LICENSE`](LICENSE) を参照。

---

## 謝辞

- Microsoft Speech API (SAPI5)
- CustomTkinter by Tom Schimansky
- loguru, pydantic, pymupdf, python-docx, python-pptx, beautifulsoup4, langid, mecab-python3

## Outlook 新着メール読み上げ（classic Outlook / 実験的）

classic Outlook for Windows がインストールされている環境では、Outlook COM を使った新着メール読み上げを試せます。既定では無効です。ユーザーが明示的に有効化するまで Outlook へはアクセスしません。

動作概要:

- Outlook Inbox をポーリングします。
- 新着メールの差出人・件名・本文冒頭を読み上げます。
- 本文冒頭を読み上げた後、全文を読むかを確認します。
- Yes の場合のみ本文全文を読み上げます。
- Outlook メール本文はログ出力せず、Outlook メール読み上げでは WAV 保存を既定で行いません。

事前確認:

```powershell
python scripts\spike_outlook_read_inbox.py
```

詳細は `docs/outlook_integration.md` を参照してください。
