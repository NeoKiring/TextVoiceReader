"""Entry point. Routes to GUI by default, or CLI mode with ``--no-gui``.

Usage:
    python -m text_voice_reader                                 # GUI
    python -m text_voice_reader --file input.txt --no-gui        # CLI, play + save (per config)
    python -m text_voice_reader --file input.md --out out.wav --no-gui --no-play
    python -m text_voice_reader --list-voices
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from text_voice_reader import __version__
from text_voice_reader.config import AppConfig, load_config
from text_voice_reader.logging_setup import get_logger, setup_logging
from text_voice_reader.orchestrator import AppOrchestrator
from text_voice_reader.utils.threading_utils import StopToken

_log = get_logger(__name__)


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="text-voice-reader",
        description="Text file to speech reader (Windows SAPI5).",
    )
    p.add_argument("--version", action="version", version=f"TextVoiceReader {__version__}")
    p.add_argument(
        "--file", "-f",
        type=Path,
        help="Input file path (txt/md/pdf/docx/pptx/html/csv/msg).",
    )
    p.add_argument(
        "--out", "-o",
        type=Path,
        default=None,
        help="Explicit output WAV path. Overrides config save_dir.",
    )
    p.add_argument(
        "--voice", "-v",
        type=str,
        default=None,
        help="Voice name or id (substring match). Overrides config.",
    )
    p.add_argument("--rate", type=int, default=None, help="Rate -10..+10. Overrides config.")
    p.add_argument("--volume", type=int, default=None, help="Volume 0..100. Overrides config.")
    p.add_argument("--pitch", type=int, default=None, help="Pitch -10..+10. Overrides config.")
    p.add_argument("--no-gui", action="store_true", help="Run in CLI mode (no window).")
    p.add_argument("--no-play", action="store_true", help="Disable audio playback (save only).")
    p.add_argument("--no-save", action="store_true", help="Disable WAV save (play only).")
    p.add_argument(
        "--list-voices",
        action="store_true",
        help="Enumerate installed SAPI5 voices and exit.",
    )
    p.add_argument(
        "--text", "-t",
        type=str,
        default=None,
        help="Synthesize inline text directly (alternative to --file).",
    )
    return p


def _apply_cli_overrides(cfg: AppConfig, args: argparse.Namespace) -> AppConfig:
    """Apply command-line overrides to a loaded config. Returns a new instance."""
    data = cfg.model_dump()
    if args.voice is not None:
        data["tts"]["voice"] = args.voice
    if args.rate is not None:
        data["tts"]["rate"] = args.rate
    if args.volume is not None:
        data["tts"]["volume"] = args.volume
    if args.pitch is not None:
        data["tts"]["pitch"] = args.pitch
    if args.no_play:
        data["output"]["play"] = False
    if args.no_save:
        data["output"]["save_wav"] = False
    return AppConfig(**data)


def _run_cli(args: argparse.Namespace, cfg: AppConfig) -> int:
    """Execute CLI workflow. Returns process exit code."""
    orch = AppOrchestrator(cfg)

    if args.list_voices:
        try:
            for v in orch.get_engine().list_voices():
                print(f"[{v.id}]  {v.name}  lang={v.language}  gender={v.gender}")
        except Exception as e:  # pragma: no cover - engine-specific
            print(f"Failed to list voices: {e}", file=sys.stderr)
            return 2
        return 0

    if not args.file and not args.text:
        print("Error: --file or --text is required in --no-gui mode", file=sys.stderr)
        return 64  # EX_USAGE

    if args.file:
        if not args.file.is_file():
            print(f"Error: file not found: {args.file}", file=sys.stderr)
            return 66  # EX_NOINPUT
        sentences = orch.load_and_prepare(args.file)
        source_name = args.file.stem
    else:
        sentences = orch.prepare_text(args.text or "")
        source_name = "inline"

    if not sentences:
        print("Warning: no sentences to speak after processing", file=sys.stderr)
        return 0

    def _print_progress(cur: int, total: int, sentence) -> None:  # noqa: ANN001
        bar_len = 20
        filled = int(bar_len * cur / total) if total else 0
        bar = "█" * filled + "░" * (bar_len - filled)
        preview = sentence.text[:40].replace("\n", " ")
        print(f"[{bar}] {cur}/{total}  {preview}", file=sys.stderr)

    result = orch.run(
        sentences,
        source_name=source_name,
        stop=StopToken(),
        progress=_print_progress,
    )

    # Handle explicit --out override
    if args.out and result.output_wav and result.output_wav != args.out:
        try:
            args.out.parent.mkdir(parents=True, exist_ok=True)
            result.output_wav.replace(args.out)
            print(f"Moved output to {args.out}")
        except OSError as e:
            print(f"Warning: could not move output: {e}", file=sys.stderr)

    print(
        "Done: "
        f"success={result.completed} "
        f"failed={result.failed} "
        f"total={result.total_sentences}",
        file=sys.stderr,
    )
    if result.output_wav:
        print(f"Output WAV: {result.output_wav}")
    if result.cancelled:
        return 130
    if result.failed > 0:
        return 1
    return 0 if result.completed > 0 else 1


def _run_gui(cfg: AppConfig) -> int:
    """Launch the CustomTkinter main window."""
    try:
        from text_voice_reader.ui.main_window import MainWindow
    except Exception as e:  # pragma: no cover
        print(f"Failed to initialize GUI: {e}", file=sys.stderr)
        return 3
    app = MainWindow(cfg)
    app.mainloop()
    return 0


def main(argv: list[str] | None = None) -> int:
    """Main entry point used by ``python -m text_voice_reader`` and console-script."""
    parser = _build_parser()
    args = parser.parse_args(argv)

    cfg = load_config()
    cfg = _apply_cli_overrides(cfg, args)
    setup_logging(cfg.logging)
    _log.info(f"TextVoiceReader {__version__} starting")

    try:
        if args.no_gui or args.list_voices:
            return _run_cli(args, cfg)
        return _run_gui(cfg)
    except KeyboardInterrupt:
        print("Interrupted", file=sys.stderr)
        return 130
    except Exception as e:  # top-level safety net
        _log.exception("Unhandled error")
        print(f"Error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
