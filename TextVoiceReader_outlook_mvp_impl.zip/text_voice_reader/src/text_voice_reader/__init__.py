"""TextVoiceReader - Text file to speech reader powered by Windows SAPI5."""

from __future__ import annotations

__version__ = "0.1.0"
__all__ = ["__version__"]
