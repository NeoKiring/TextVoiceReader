"""Entry point for `python -m text_voice_reader`."""

from __future__ import annotations

from text_voice_reader.app import main

if __name__ == "__main__":
    raise SystemExit(main())
