"""Placeholder ONNX-based TTS engine (Phase 5 extension).

This module is imported lazily only when ``AppConfig.tts.engine == "onnx"``.
Filling in the actual inference code is intentionally left for a later phase
because the required model artifacts (acoustic model, vocoder, lexicon) and
their exact pre/post-processing depend on the chosen model family
(VITS, Tacotron2, etc.).

The class is kept as a typed stub so that the rest of the system (factory,
orchestrator, UI) remains engine-agnostic.
"""

from __future__ import annotations

from pathlib import Path

from text_voice_reader.tts.base import SpeechHandle, TtsError
from text_voice_reader.tts.options import SynthesisOptions, VoiceInfo


class OnnxTtsEngine:
    """Not yet implemented. Configure ``tts.engine = 'sapi5'`` for now."""

    name: str = "onnx"

    def __init__(self, model_path: str = "") -> None:
        self._model_path = Path(model_path) if model_path else None
        # Placeholder for future ORT session:
        # import onnxruntime as ort
        # self._session = ort.InferenceSession(model_path, providers=[...])

    def list_voices(self) -> list[VoiceInfo]:  # pragma: no cover - stub
        raise TtsError("OnnxTtsEngine is not implemented yet")

    def synthesize_to_file(
        self, text: str, wav_path: Path, opts: SynthesisOptions
    ) -> None:  # pragma: no cover - stub
        raise TtsError("OnnxTtsEngine is not implemented yet")

    def speak_async(
        self, text: str, opts: SynthesisOptions
    ) -> SpeechHandle:  # pragma: no cover - stub
        raise TtsError("OnnxTtsEngine is not implemented yet")


__all__ = ["OnnxTtsEngine"]
