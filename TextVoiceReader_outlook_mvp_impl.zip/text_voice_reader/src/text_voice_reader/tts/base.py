"""TTS engine protocol and handle type."""

from __future__ import annotations

from pathlib import Path
from typing import Protocol, runtime_checkable

from text_voice_reader.loaders.base import TvrError
from text_voice_reader.tts.options import SynthesisOptions, VoiceInfo


class TtsError(TvrError):
    """Raised for TTS engine failures."""


class SpeechHandle(Protocol):
    """Handle for an in-flight asynchronous speech task.

    Implementations must be safe to call from any thread.
    """

    def wait(self, timeout_ms: int = -1) -> None:
        """Block until speech finishes or ``timeout_ms`` elapses."""
        ...

    def stop(self) -> None:
        """Abort the speech immediately."""
        ...

    def pause(self) -> None:
        """Pause the speech; resume with :meth:`resume`."""
        ...

    def resume(self) -> None:
        """Resume previously paused speech."""
        ...

    @property
    def is_done(self) -> bool:
        """True once the speech has finished or was stopped."""
        ...


@runtime_checkable
class TtsEngine(Protocol):
    """Interface for all TTS engines."""

    name: str

    def list_voices(self) -> list[VoiceInfo]:
        """Enumerate available voices."""
        ...

    def synthesize_to_file(
        self, text: str, wav_path: Path, opts: SynthesisOptions
    ) -> None:
        """Synthesize ``text`` to a WAV file at ``wav_path`` (blocking)."""
        ...

    def speak_async(self, text: str, opts: SynthesisOptions) -> SpeechHandle:
        """Begin asynchronous speech; return a handle for control."""
        ...


__all__ = ["SpeechHandle", "TtsEngine", "TtsError"]
