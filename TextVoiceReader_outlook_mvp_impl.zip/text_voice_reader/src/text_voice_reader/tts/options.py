"""Value objects for the TTS layer."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class VoiceInfo:
    """Information about an installed TTS voice.

    Attributes:
        id: Engine-specific identifier (e.g. SAPI5 token ID path).
        name: Display name shown to the user.
        language: ISO-like language tag (best-effort; may be empty).
        gender: "male" / "female" / "" if unknown.
        engine: Engine short name ("sapi5", "onnx", ...).
    """

    id: str
    name: str
    language: str = ""
    gender: str = ""
    engine: str = ""


@dataclass(frozen=True)
class SynthesisOptions:
    """Per-call synthesis parameters.

    Attributes:
        voice_id: If empty, the engine's default/first voice is used.
        rate: SAPI5-style rate -10..+10 (0 = normal).
        volume: Volume 0..100.
        pitch: Pitch scale -10..+10 (applied via SSML).
        use_ssml: Whether to wrap text in SSML for pitch control.
        sample_rate: Output sample rate in Hz (22050 or 44100 typical).
    """

    voice_id: str = ""
    rate: int = 0
    volume: int = 90
    pitch: int = 0
    use_ssml: bool = True
    sample_rate: int = 22050


__all__ = ["SynthesisOptions", "VoiceInfo"]
