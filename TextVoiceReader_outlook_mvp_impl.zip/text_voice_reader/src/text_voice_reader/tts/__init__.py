"""TTS engine layer."""

from text_voice_reader.tts.base import SpeechHandle, TtsEngine, TtsError
from text_voice_reader.tts.onnx_engine import OnnxTtsEngine
from text_voice_reader.tts.options import SynthesisOptions, VoiceInfo


def create_engine(name: str, onnx_model_path: str = "") -> TtsEngine:
    """Instantiate the requested TTS engine by name.

    Args:
        name: Engine name ("sapi5" or "onnx").
        onnx_model_path: Path to ONNX model (only used when name == "onnx").

    Returns:
        A concrete :class:`TtsEngine` implementation.

    Raises:
        TtsError: if the name is unknown.
    """
    lowered = (name or "").lower()
    if lowered == "sapi5":
        # Lazy import to avoid loading pywin32 when not needed
        from text_voice_reader.tts.sapi5_engine import Sapi5Engine
        return Sapi5Engine()
    if lowered == "onnx":
        return OnnxTtsEngine(onnx_model_path)
    raise TtsError(f"Unknown TTS engine: {name!r}")


__all__ = [
    "OnnxTtsEngine",
    "SpeechHandle",
    "SynthesisOptions",
    "TtsEngine",
    "TtsError",
    "VoiceInfo",
    "create_engine",
]
