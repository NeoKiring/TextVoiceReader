"""SAPI5-based TTS engine via pywin32.

This is the primary engine for the application. It wraps the Windows
Speech API (SAPI5) through its COM automation interface (``SAPI.SpVoice``).

Key operations:
    * List voices via ``GetVoices()``.
    * Synthesize to WAV file via ``SpFileStream``.
    * Asynchronous speech via ``Speak(..., SVSFlagsAsync)``.
    * Pause/Resume/Stop via the voice object's methods.

On non-Windows platforms, importing this module still succeeds (so tests can
mock it), but calling any method will raise :class:`TtsError` because
``pywin32`` / ``win32com.client`` is unavailable.
"""

from __future__ import annotations

import sys
import threading
from contextlib import contextmanager
from pathlib import Path

from text_voice_reader.logging_setup import get_logger
from text_voice_reader.processing.ssml_builder import build_ssml
from text_voice_reader.tts.base import SpeechHandle, TtsError
from text_voice_reader.tts.options import SynthesisOptions, VoiceInfo

_log = get_logger(__name__)

# SAPI5 constants (from SpeechLib.h). Keep as module-level for clarity.
SSFM_CREATE_FOR_WRITE = 3
SVSF_DEFAULT = 0
SVSF_ASYNC = 1
SVSF_PURGE_BEFORE_SPEAK = 2
SVSF_IS_XML = 8

# Audio format type codes for SpAudioFormat.Type
# (subset of SpeechAudioFormatType - matches registry strings too)
SAFT_22kHz16BitMono = 22
SAFT_44kHz16BitMono = 34


def _require_win32():
    """Import and return ``win32com.client``, or raise a helpful TtsError."""
    if not sys.platform.startswith("win"):
        raise TtsError("SAPI5 is only available on Windows")
    try:
        import win32com.client  # type: ignore[import-not-found]

        return win32com.client
    except ImportError as e:
        raise TtsError(
            "pywin32 is not installed or could not be loaded. "
            "Run: pip install pywin32"
        ) from e


def _require_pythoncom():
    """Import and return ``pythoncom``, or raise a helpful TtsError."""
    if not sys.platform.startswith("win"):
        raise TtsError("SAPI5 is only available on Windows")
    try:
        import pythoncom  # type: ignore[import-not-found]

        return pythoncom
    except ImportError as e:
        raise TtsError(
            "pywin32 is not installed or could not be loaded. "
            "Run: pip install pywin32"
        ) from e


@contextmanager
def _com_scope():
    """Initialize COM for the current thread for the duration of the scope."""
    pythoncom = _require_pythoncom()
    pythoncom.CoInitialize()
    try:
        yield
    finally:
        pythoncom.CoUninitialize()


class _Sapi5Handle:
    """Concrete :class:`SpeechHandle` backed by a SAPI5 voice."""

    def __init__(self, speaker, pythoncom) -> None:
        self._speaker = speaker
        self._pythoncom = pythoncom
        self._done = threading.Event()
        self._stopped = False
        self._released = False

    def wait(self, timeout_ms: int = -1) -> None:
        # SpVoice.WaitUntilDone uses ms; -1 means infinite.
        try:
            self._speaker.WaitUntilDone(timeout_ms)
        finally:
            self._done.set()
            self._release_com()

    def stop(self) -> None:
        # Speak empty string with PurgeBeforeSpeak to cancel current speech.
        try:
            self._speaker.Speak("", SVSF_ASYNC | SVSF_PURGE_BEFORE_SPEAK)
        except Exception as e:
            _log.warning(f"SAPI5 stop failed: {e}")
        self._stopped = True
        self._done.set()
        self._release_com()

    def pause(self) -> None:
        try:
            self._speaker.Pause()
        except Exception as e:
            _log.warning(f"SAPI5 pause failed: {e}")

    def resume(self) -> None:
        try:
            self._speaker.Resume()
        except Exception as e:
            _log.warning(f"SAPI5 resume failed: {e}")

    @property
    def is_done(self) -> bool:
        return self._done.is_set() or self._stopped

    def _release_com(self) -> None:
        if self._released:
            return
        self._released = True
        try:
            self._pythoncom.CoUninitialize()
        except Exception:
            pass


class Sapi5Engine:
    """SAPI5-backed TTS engine."""

    name: str = "sapi5"

    def __init__(self) -> None:
        self._w32 = _require_win32()
        self._voices_cache: list[VoiceInfo] | None = None

    # -----------------------------------------------------------------
    # Voice enumeration
    # -----------------------------------------------------------------

    def list_voices(self) -> list[VoiceInfo]:
        """Enumerate all installed SAPI5 voices.

        The result is cached on first call. Voice selection is done by
        matching against the ``name`` field (case-insensitive substring).
        """
        if self._voices_cache is not None:
            return self._voices_cache

        result: list[VoiceInfo] = []
        try:
            with _com_scope():
                speaker = self._w32.Dispatch("SAPI.SpVoice")
                voices = speaker.GetVoices()
                for i in range(voices.Count):
                    token = voices.Item(i)
                    try:
                        description = token.GetDescription()
                    except Exception:
                        description = f"Voice {i}"
                    language = ""
                    gender = ""
                    try:
                        # Attributes are accessed as IDataObject properties
                        attr = token.GetAttribute  # bound method
                        language = attr("Language") or ""
                        gender = (attr("Gender") or "").lower()
                    except Exception:
                        pass
                    result.append(
                        VoiceInfo(
                            id=token.Id,
                            name=description,
                            language=language,
                            gender=gender,
                            engine=self.name,
                        )
                    )
        except Exception as e:
            raise TtsError(f"Failed to enumerate SAPI5 voices: {e}") from e

        self._voices_cache = result
        _log.info(f"Enumerated {len(result)} SAPI5 voices")
        return result


    # -----------------------------------------------------------------
    # Voice selection
    # -----------------------------------------------------------------

    def _select_voice(self, speaker, voice_id_or_name: str) -> None:
        """Set the current voice by exact id or substring name match."""
        if not voice_id_or_name:
            return
        target = voice_id_or_name.lower()
        voices = speaker.GetVoices()
        for i in range(voices.Count):
            token = voices.Item(i)
            try:
                desc = token.GetDescription() or ""
                tid = token.Id or ""
            except Exception:
                continue
            if target == tid.lower() or target in desc.lower():
                speaker.Voice = token
                _log.debug(f"Selected voice: {desc}")
                return
        _log.warning(f"Voice '{voice_id_or_name}' not found; using default")

    # -----------------------------------------------------------------
    # File output
    # -----------------------------------------------------------------

    def synthesize_to_file(
        self, text: str, wav_path: Path, opts: SynthesisOptions
    ) -> None:
        """Synthesize ``text`` to a WAV file at ``wav_path`` (blocking).

        Raises:
            TtsError: on any SAPI5 failure.
        """
        if not text:
            raise TtsError("Cannot synthesize empty text")
        wav_path.parent.mkdir(parents=True, exist_ok=True)

        payload, flags = self._prepare_payload(text, opts)

        try:
            with _com_scope():
                speaker = self._w32.Dispatch("SAPI.SpVoice")
                self._select_voice(speaker, opts.voice_id)
                self._apply_prosody(speaker, opts)

                stream = self._w32.Dispatch("SAPI.SpFileStream")
                fmt = self._make_format(opts.sample_rate)
                if fmt is not None:
                    stream.Format = fmt

                try:
                    stream.Open(str(wav_path), SSFM_CREATE_FOR_WRITE, False)
                except Exception as e:
                    raise TtsError(f"Failed to open output WAV {wav_path}: {e}") from e

                original_output = speaker.AudioOutputStream
                try:
                    speaker.AudioOutputStream = stream
                    # Synchronous write so file is complete on return.
                    speaker.Speak(payload, flags & ~SVSF_ASYNC)
                except Exception as e:
                    raise TtsError(f"SAPI5 synthesis failed: {e}") from e
                finally:
                    try:
                        stream.Close()
                    except Exception:
                        pass
                    try:
                        speaker.AudioOutputStream = original_output
                    except Exception:
                        pass
        except TtsError:
            raise
        except Exception as e:
            raise TtsError(f"SAPI5 synthesis failed: {e}") from e

        _log.info(
            f"Synthesized WAV: {wav_path} "
            f"({wav_path.stat().st_size if wav_path.exists() else '?'} bytes)"
        )

    # -----------------------------------------------------------------
    # Async playback
    # -----------------------------------------------------------------

    def speak_async(self, text: str, opts: SynthesisOptions) -> SpeechHandle:
        """Begin asynchronous speech via the default audio output."""
        if not text:
            raise TtsError("Cannot speak empty text")

        payload, flags = self._prepare_payload(text, opts)
        flags |= SVSF_ASYNC

        pythoncom = _require_pythoncom()
        pythoncom.CoInitialize()
        try:
            speaker = self._w32.Dispatch("SAPI.SpVoice")
            self._select_voice(speaker, opts.voice_id)
            self._apply_prosody(speaker, opts)
            speaker.Speak(payload, flags)
        except Exception as e:
            try:
                pythoncom.CoUninitialize()
            except Exception:
                pass
            raise TtsError(f"SAPI5 async speak failed: {e}") from e

        return _Sapi5Handle(speaker, pythoncom)

    # -----------------------------------------------------------------
    # Internal helpers
    # -----------------------------------------------------------------

    def _apply_prosody(self, speaker, opts: SynthesisOptions) -> None:
        """Set rate/volume on the COM speaker."""
        try:
            speaker.Rate = int(opts.rate)
            speaker.Volume = int(opts.volume)
        except Exception as e:
            _log.warning(f"Failed to set prosody: {e}")

    def _prepare_payload(self, text: str, opts: SynthesisOptions) -> tuple[str, int]:
        """Build the payload string and SAPI flags."""
        if opts.use_ssml and opts.pitch != 0:
            payload = build_ssml(text, pitch=opts.pitch)
            flags = SVSF_IS_XML
        else:
            payload = text
            flags = SVSF_DEFAULT
        return payload, flags

    def _make_format(self, sample_rate: int):
        """Build an SpAudioFormat object for WAV output."""
        try:
            fmt = self._w32.Dispatch("SAPI.SpAudioFormat")
            if sample_rate >= 44100:
                fmt.Type = SAFT_44kHz16BitMono
            else:
                fmt.Type = SAFT_22kHz16BitMono
            return fmt
        except Exception as e:
            _log.warning(f"Failed to build SpAudioFormat: {e}; using default")
            return None


__all__ = ["Sapi5Engine"]
