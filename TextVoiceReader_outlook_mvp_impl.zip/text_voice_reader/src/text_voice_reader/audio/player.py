"""WAV file player using the standard library ``winsound`` module.

This is used in hybrid mode (synthesize-to-file, then play). For pure
"play-only" mode, callers typically use :meth:`Sapi5Engine.speak_async`
directly, which bypasses file I/O entirely.
"""

from __future__ import annotations

import sys
import threading
import wave
from pathlib import Path

from text_voice_reader.audio.wav_exporter import AudioError
from text_voice_reader.logging_setup import get_logger

_log = get_logger(__name__)


class AudioPlayer:
    """Plays WAV files. Windows-only via ``winsound``.

    On non-Windows platforms :meth:`play_sync` raises :class:`AudioError`.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()

    def play_sync(self, wav_path: Path) -> None:
        """Play ``wav_path`` synchronously (block until complete)."""
        if not sys.platform.startswith("win"):
            raise AudioError("AudioPlayer requires Windows")
        if not wav_path.is_file():
            raise AudioError(f"WAV file not found: {wav_path}")

        import winsound  # stdlib, Windows-only

        with self._lock:
            try:
                winsound.PlaySound(
                    str(wav_path),
                    winsound.SND_FILENAME | winsound.SND_NODEFAULT,
                )
            except RuntimeError as e:
                raise AudioError(f"Failed to play {wav_path}: {e}") from e

    def stop(self) -> None:
        """Stop any in-progress playback from this player."""
        if not sys.platform.startswith("win"):
            return
        import winsound

        try:
            winsound.PlaySound(None, winsound.SND_PURGE)
        except RuntimeError as e:
            _log.warning(f"Failed to stop playback: {e}")

    @staticmethod
    def get_duration_seconds(wav_path: Path) -> float:
        """Return duration in seconds of the given WAV file."""
        with wave.open(str(wav_path), "rb") as w:
            frames = w.getnframes()
            rate = w.getframerate()
        return frames / float(rate) if rate else 0.0


__all__ = ["AudioPlayer"]
