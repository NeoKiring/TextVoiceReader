"""HybridSink: synthesize each sentence once, then play + save in parallel.

Approach
========
For each sentence the orchestrator passes in:

1. The TTS engine writes a per-sentence WAV to a temp file (single synthesis).
2. :class:`WavExporter` appends that WAV to the final combined output.
3. :class:`AudioPlayer` plays the per-sentence WAV (blocks until complete).

This yields a fully-saved WAV of the entire text while simultaneously
providing low-latency playback, all from a single synthesis per sentence.
"""

from __future__ import annotations

import tempfile
import uuid
from pathlib import Path

from text_voice_reader.audio.player import AudioPlayer
from text_voice_reader.audio.wav_exporter import WavExporter
from text_voice_reader.logging_setup import get_logger
from text_voice_reader.tts.base import TtsEngine
from text_voice_reader.tts.options import SynthesisOptions
from text_voice_reader.utils.threading_utils import StopToken

_log = get_logger(__name__)


class HybridSink:
    """Coordinates per-sentence synthesis, playback, and file export.

    Either or both of ``play`` and ``save_path`` can be enabled:

    * play only:    temp WAV is created, played, then deleted
    * save only:    temp WAV is synthesized and appended; no playback
    * hybrid:       both happen for each sentence
    """

    def __init__(
        self,
        engine: TtsEngine,
        *,
        play: bool = True,
        save_path: Path | None = None,
        temp_dir: Path | None = None,
    ) -> None:
        self._engine = engine
        self._play = play
        self._save_path = save_path
        self._temp_dir = temp_dir
        self._player = AudioPlayer() if play else None
        self._exporter: WavExporter | None = WavExporter(save_path) if save_path else None
        self._run_id = uuid.uuid4().hex[:8]
        self._counter = 0

    def consume(self, text: str, opts: SynthesisOptions, stop: StopToken) -> None:
        """Synthesize one sentence and dispatch to enabled outputs.

        Args:
            text: Sentence text to speak.
            opts: Synthesis parameters.
            stop: Cancellation token - checked before expensive work.
        """
        if stop.is_set():
            return

        self._counter += 1
        temp_wav = self._make_temp_path()

        try:
            self._engine.synthesize_to_file(text, temp_wav, opts)
            if stop.is_set():
                return

            if self._exporter is not None:
                self._exporter.append(temp_wav)

            if self._player is not None and not stop.is_set():
                self._player.play_sync(temp_wav)
        finally:
            self._cleanup_temp(temp_wav)

    def close(self) -> None:
        """Finalize the output WAV (if any) and release resources."""
        if self._exporter is not None:
            self._exporter.close()
            self._exporter = None
        if self._player is not None:
            self._player.stop()

    # -----------------------------------------------------------------
    # Internals
    # -----------------------------------------------------------------

    def _make_temp_path(self) -> Path:
        base = self._temp_dir or Path(tempfile.gettempdir())
        base.mkdir(parents=True, exist_ok=True)
        return base / f"tvr_{self._run_id}_{self._counter:04d}.wav"

    @staticmethod
    def _cleanup_temp(path: Path) -> None:
        try:
            if path.exists():
                path.unlink()
        except OSError as e:
            _log.debug(f"Could not remove temp file {path}: {e}")

    def __enter__(self) -> HybridSink:
        return self

    def __exit__(self, *exc_info: object) -> None:
        self.close()


__all__ = ["HybridSink"]
