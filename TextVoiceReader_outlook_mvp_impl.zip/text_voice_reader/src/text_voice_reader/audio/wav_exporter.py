"""WAV file exporter with concat support using Python's stdlib ``wave``."""

from __future__ import annotations

import wave
from pathlib import Path

from text_voice_reader.loaders.base import TvrError


class AudioError(TvrError):
    """Raised for audio I/O failures."""


class WavExporter:
    """Append-mode WAV writer that concatenates compatible PCM WAV files.

    Usage:
        >>> exp = WavExporter(Path("out.wav"))
        >>> exp.append(Path("sentence_1.wav"))
        >>> exp.append(Path("sentence_2.wav"))
        >>> exp.close()

    All appended files must share the same sample rate, channel count, and
    sample width. The first append determines the format; subsequent appends
    are validated and raise :class:`AudioError` on mismatch.
    """

    def __init__(self, target: Path) -> None:
        self._target = target
        self._target.parent.mkdir(parents=True, exist_ok=True)
        self._writer: wave.Wave_write | None = None
        self._params: wave._wave_params | None = None  # type: ignore[name-defined]

    def append(self, wav_path: Path) -> None:
        """Append the PCM data from ``wav_path`` to the output file."""
        if not wav_path.is_file():
            raise AudioError(f"Input WAV not found: {wav_path}")

        with wave.open(str(wav_path), "rb") as reader:
            params = reader.getparams()
            frames = reader.readframes(reader.getnframes())

        if self._writer is None:
            self._writer = wave.open(str(self._target), "wb")
            self._writer.setparams(params)
            self._params = params
        else:
            if params[:3] != self._params[:3]:  # type: ignore[index]
                raise AudioError(
                    f"WAV format mismatch: new={params[:3]} "
                    f"existing={self._params[:3]}"  # type: ignore[index]
                )
        self._writer.writeframes(frames)

    def close(self) -> None:
        """Close the output file. Safe to call multiple times."""
        if self._writer is not None:
            try:
                self._writer.close()
            except Exception:
                pass
            self._writer = None

    def __enter__(self) -> WavExporter:
        return self

    def __exit__(self, *exc_info: object) -> None:
        self.close()


__all__ = ["AudioError", "WavExporter"]
