"""Application orchestrator.

Coordinates:
    Loader → Normalizer → Splitter → TTS engine → Audio sink (play/save/both)

The orchestrator exposes high-level use-cases:
    * :meth:`load_and_prepare` - read a file and return ready-to-speak sentences
    * :meth:`run` - execute synthesis + output end-to-end (blocking)

Callers from the UI layer should wrap :meth:`run` in a worker thread and
use :class:`StopToken` to cancel.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Callable

from text_voice_reader.audio.hybrid_sink import HybridSink
from text_voice_reader.config import AppConfig
from text_voice_reader.loaders.factory import LoaderFactory
from text_voice_reader.logging_setup import get_logger
from text_voice_reader.processing.lang_detector import LanguageDetector
from text_voice_reader.processing.normalizer import NormalizerOptions, TextNormalizer
from text_voice_reader.processing.splitter import Sentence, SentenceSplitter, SplitterOptions
from text_voice_reader.tts import create_engine
from text_voice_reader.tts.base import TtsEngine
from text_voice_reader.tts.options import SynthesisOptions
from text_voice_reader.utils.paths import ensure_dir
from text_voice_reader.utils.threading_utils import StopToken

_log = get_logger(__name__)


ProgressCallback = Callable[[int, int, Sentence], None]
"""Signature: (current_index, total, sentence) -> None."""


@dataclass
class RunResult:
    """Outcome of a synthesis run."""

    total_sentences: int
    completed: int
    failed: int
    output_wav: Path | None
    cancelled: bool


class AppOrchestrator:
    """High-level facade over all TextVoiceReader subsystems."""

    def __init__(self, config: AppConfig) -> None:
        self._cfg = config
        self._loader_factory = LoaderFactory(
            pdf_strip_headers=config.processing.pdf_strip_headers
        )
        self._normalizer = TextNormalizer(
            NormalizerOptions(
                nfkc=config.processing.normalize_nfkc,
                strip_urls=config.processing.strip_urls,
                skip_empty_lines=config.processing.skip_empty_lines,
            )
        )
        self._splitter = SentenceSplitter(
            SplitterOptions(max_chars=config.processing.split_max_chars)
        )
        self._lang_detector = LanguageDetector()
        self._engine: TtsEngine | None = None

    # -----------------------------------------------------------------
    # Engine management
    # -----------------------------------------------------------------

    def get_engine(self) -> TtsEngine:
        """Lazily create and return the configured TTS engine."""
        if self._engine is None:
            self._engine = create_engine(
                self._cfg.tts.engine,
                onnx_model_path=self._cfg.tts.onnx_model_path,
            )
            _log.info(f"TTS engine initialized: {self._engine.name}")
        return self._engine

    def supported_extensions(self) -> set[str]:
        """Return the union of all supported input extensions."""
        return self._loader_factory.supported_extensions()

    # -----------------------------------------------------------------
    # Use cases
    # -----------------------------------------------------------------

    def load_and_prepare(self, path: Path) -> list[Sentence]:
        """Load a file and return a list of sentences ready for TTS.

        Args:
            path: Input file path.

        Returns:
            List of :class:`Sentence` in reading order.
        """
        loader = self._loader_factory.resolve(path)
        _log.info(f"Loading {path.name} with {type(loader).__name__}")
        raw = loader.load(path)
        normalized = self._normalizer.normalize(raw)
        sentences = self._splitter.split(normalized)
        # Annotate language on each sentence (best-effort)
        result: list[Sentence] = []
        for s in sentences:
            info = self._lang_detector.detect(s.text)
            result.append(Sentence(id=s.id, text=s.text, language=info.language))
        _log.info(f"Prepared {len(result)} sentences from {path.name}")
        return result

    def prepare_text(self, text: str) -> list[Sentence]:
        """Same as :meth:`load_and_prepare` but from raw text."""
        normalized = self._normalizer.normalize(text)
        sentences = self._splitter.split(normalized)
        out: list[Sentence] = []
        for s in sentences:
            info = self._lang_detector.detect(s.text)
            out.append(Sentence(id=s.id, text=s.text, language=info.language))
        return out

    def run(
        self,
        sentences: list[Sentence],
        *,
        play: bool | None = None,
        save_wav: bool | None = None,
        source_name: str = "input",
        stop: StopToken | None = None,
        progress: ProgressCallback | None = None,
    ) -> RunResult:
        """Execute synthesis for the given sentences.

        Args:
            sentences: Sentences to speak.
            play: Override config "output.play". None = use config value.
            save_wav: Override config "output.save_wav". None = use config.
            source_name: Used for the output filename.
            stop: Cancellation token.
            progress: Optional callback invoked after each sentence.

        Returns:
            :class:`RunResult` describing the outcome.
        """
        stop = stop or StopToken()
        play_flag = self._cfg.output.play if play is None else play
        save_flag = self._cfg.output.save_wav if save_wav is None else save_wav

        if not play_flag and not save_flag:
            raise ValueError("At least one of play or save_wav must be enabled")

        save_path: Path | None = None
        if save_flag:
            save_dir = ensure_dir(self._cfg.resolved_save_dir())
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            safe_base = self._safe_stem(source_name)
            save_path = save_dir / f"{safe_base}_{ts}.wav"

        engine = self.get_engine()
        opts = SynthesisOptions(
            voice_id=self._cfg.tts.voice,
            rate=self._cfg.tts.rate,
            volume=self._cfg.tts.volume,
            pitch=self._cfg.tts.pitch,
            use_ssml=self._cfg.tts.use_ssml,
            sample_rate=self._cfg.output.wav_sample_rate,
        )

        total = len(sentences)
        completed = 0
        failed = 0
        with HybridSink(
            engine,
            play=play_flag,
            save_path=save_path,
            temp_dir=self._cfg.resolved_temp_dir(),
        ) as sink:
            for idx, sentence in enumerate(sentences, start=1):
                if stop.is_set():
                    _log.info("Run cancelled by stop token")
                    return RunResult(
                        total_sentences=total,
                        completed=completed,
                        failed=failed,
                        output_wav=save_path,
                        cancelled=True,
                    )
                try:
                    sink.consume(sentence.text, opts, stop)
                    completed += 1
                    if progress is not None:
                        progress(idx, total, sentence)
                except Exception as e:
                    failed += 1
                    _log.exception(f"Failed on sentence {sentence.id}: {e}")
                    # Continue with next sentence rather than abort full run
                    continue

        _log.info(
            f"Run complete: completed={completed}, failed={failed}, "
            f"total={total}, output={save_path}"
        )
        return RunResult(
            total_sentences=total,
            completed=completed,
            failed=failed,
            output_wav=save_path,
            cancelled=False,
        )

    # -----------------------------------------------------------------
    # Internals
    # -----------------------------------------------------------------

    @staticmethod
    def _safe_stem(name: str) -> str:
        """Return a filesystem-safe version of ``name``."""
        bad = '<>:"/\\|?*'
        return "".join("_" if c in bad else c for c in name)[:80] or "output"


__all__ = ["AppOrchestrator", "ProgressCallback", "RunResult"]
