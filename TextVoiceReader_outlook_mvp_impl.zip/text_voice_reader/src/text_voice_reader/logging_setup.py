"""Loguru-based logging initialization."""

from __future__ import annotations

import sys
from pathlib import Path

from loguru import logger

from text_voice_reader.config import LoggingSection
from text_voice_reader.utils.paths import get_user_log_dir


def setup_logging(cfg: LoggingSection, app_name: str = "TextVoiceReader") -> None:
    """Configure loguru sinks based on config.

    Args:
        cfg: Logging config section.
        app_name: Used for log file name.
    """
    logger.remove()
    level = cfg.level

    # Console sink
    logger.add(
        sys.stderr,
        level=level,
        format=(
            "<green>{time:YYYY-MM-DD HH:mm:ss}</green> "
            "| <level>{level: <8}</level> "
            "| <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> "
            "| {message}"
        ),
        enqueue=True,
    )

    # File sink
    if cfg.log_to_file:
        log_dir: Path = get_user_log_dir()
        log_dir.mkdir(parents=True, exist_ok=True)
        log_path = log_dir / f"{app_name}.log"
        logger.add(
            str(log_path),
            level=level,
            rotation=cfg.rotation,
            retention=cfg.retention,
            encoding="utf-8",
            enqueue=True,
            format=(
                "{time:YYYY-MM-DD HH:mm:ss.SSS} | {level: <8} | "
                "{name}:{function}:{line} | {message}"
            ),
        )


def get_logger(module: str):
    """Return a bound logger for the given module name."""
    return logger.bind(module=module)


__all__ = ["setup_logging", "get_logger"]
