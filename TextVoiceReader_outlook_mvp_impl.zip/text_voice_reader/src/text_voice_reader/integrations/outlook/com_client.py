"""Classic Outlook COM client.

All COM work is isolated in this module.  Public methods initialize COM for the
current thread and return only plain Python dataclasses.
"""

from __future__ import annotations

import sys
from contextlib import contextmanager
from datetime import datetime
from typing import Any

from text_voice_reader.integrations.outlook.models import OutlookMailSnapshot
from text_voice_reader.integrations.outlook.sanitizer import MailBodySanitizer
from text_voice_reader.logging_setup import get_logger

_log = get_logger(__name__)

MAIL_ITEM_CLASS = 43
OL_FOLDER_INBOX = 6


class OutlookIntegrationError(RuntimeError):
    """Raised for Outlook integration failures."""


def _require_windows() -> None:
    if not sys.platform.startswith("win"):
        raise OutlookIntegrationError("Outlook COM is only available on Windows")


def _require_pythoncom():
    _require_windows()
    try:
        import pythoncom  # type: ignore[import-not-found]

        return pythoncom
    except ImportError as e:
        raise OutlookIntegrationError(
            "pywin32 is not installed or could not be loaded. Run: pip install pywin32"
        ) from e


def _require_win32com_client():
    _require_windows()
    try:
        import win32com.client  # type: ignore[import-not-found]

        return win32com.client
    except ImportError as e:
        raise OutlookIntegrationError(
            "pywin32 is not installed or could not be loaded. Run: pip install pywin32"
        ) from e


@contextmanager
def _com_scope():
    pythoncom = _require_pythoncom()
    pythoncom.CoInitialize()
    try:
        yield
    finally:
        pythoncom.CoUninitialize()


class OutlookComClient:
    """Small wrapper around classic Outlook COM automation."""

    def __init__(
        self,
        *,
        allow_start_outlook: bool = False,
        body_preview_max_chars: int = 300,
        full_body_max_chars: int = 0,
        sanitizer: MailBodySanitizer | None = None,
    ) -> None:
        self._allow_start_outlook = allow_start_outlook
        self._body_preview_max_chars = body_preview_max_chars
        self._full_body_max_chars = full_body_max_chars
        self._sanitizer = sanitizer or MailBodySanitizer()

    def list_recent_messages(
        self,
        *,
        limit: int = 10,
        unread_only: bool = False,
        ignore_empty_subject: bool = True,
    ) -> list[OutlookMailSnapshot]:
        """Return recent Inbox mail snapshots.

        The returned list contains no COM objects.
        """
        if limit <= 0:
            return []
        try:
            with _com_scope():
                app = self._get_application()
                namespace = app.GetNamespace("MAPI")
                inbox = namespace.GetDefaultFolder(OL_FOLDER_INBOX)
                items = inbox.Items
                try:
                    items.Sort("[ReceivedTime]", True)
                except Exception as e:
                    _log.warning(f"Outlook Items.Sort failed; continuing unsorted: {e}")

                snapshots: list[OutlookMailSnapshot] = []
                count = int(getattr(items, "Count", 0) or 0)
                for idx in range(1, count + 1):
                    if len(snapshots) >= limit:
                        break
                    try:
                        item = items.Item(idx)
                    except Exception as e:
                        _log.warning(f"Failed to access Outlook item {idx}: {e}")
                        continue
                    snapshot = self.extract_mail_snapshot(item)
                    if snapshot is None:
                        continue
                    if unread_only and not snapshot.unread:
                        continue
                    if ignore_empty_subject and not snapshot.subject.strip():
                        continue
                    snapshots.append(snapshot)
                return snapshots
        except OutlookIntegrationError:
            raise
        except Exception as e:
            raise OutlookIntegrationError(f"Failed to read Outlook Inbox: {e}") from e

    def list_unread_messages(
        self,
        *,
        limit: int = 10,
        ignore_empty_subject: bool = True,
    ) -> list[OutlookMailSnapshot]:
        """Return recent unread Inbox mail snapshots."""
        return self.list_recent_messages(
            limit=limit,
            unread_only=True,
            ignore_empty_subject=ignore_empty_subject,
        )

    def mark_as_read(self, entry_id: str) -> bool:
        """Mark a mail item as read by EntryID.

        Returns False when the entry id is empty or the item is not a MailItem.
        """
        if not entry_id:
            return False
        try:
            with _com_scope():
                app = self._get_application()
                namespace = app.GetNamespace("MAPI")
                item = namespace.GetItemFromID(entry_id)
                if int(getattr(item, "Class", 0) or 0) != MAIL_ITEM_CLASS:
                    return False
                item.UnRead = False
                item.Save()
                return True
        except Exception as e:
            raise OutlookIntegrationError(f"Failed to mark Outlook mail as read: {e}") from e

    def extract_mail_snapshot(self, item: Any) -> OutlookMailSnapshot | None:
        """Convert a COM MailItem-like object to a plain snapshot."""
        try:
            if int(getattr(item, "Class", 0) or 0) != MAIL_ITEM_CLASS:
                return None
        except Exception:
            return None

        subject = self._safe_str_attr(item, "Subject")
        sender_name = self._safe_str_attr(item, "SenderName")
        sender_email = self._safe_optional_str_attr(item, "SenderEmailAddress")
        received_at = self._safe_datetime_attr(item, "ReceivedTime")
        unread = self._safe_bool_attr(item, "UnRead")
        entry_id = self._safe_str_attr(item, "EntryID")
        body = self._safe_str_attr(item, "Body")
        if not body:
            body = self._safe_str_attr(item, "HTMLBody")

        preview = self._sanitizer.preview(
            body,
            max_chars=max(0, self._body_preview_max_chars),
        )
        full_body = self._sanitizer.full_body(
            body,
            max_chars=max(0, self._full_body_max_chars),
        )
        return OutlookMailSnapshot(
            entry_id=entry_id,
            subject=subject,
            sender_name=sender_name,
            sender_email=sender_email,
            received_at=received_at,
            body_preview=preview,
            full_body=full_body,
            unread=unread,
        )

    def _get_application(self):
        win32 = _require_win32com_client()
        try:
            return win32.GetActiveObject("Outlook.Application")
        except Exception as active_error:
            if not self._allow_start_outlook:
                raise OutlookIntegrationError(
                    "Could not attach to a running classic Outlook instance. "
                    "Start Outlook first, or enable allow_start_outlook for the spike/manual test."
                ) from active_error
            try:
                return win32.Dispatch("Outlook.Application")
            except Exception as dispatch_error:
                raise OutlookIntegrationError(
                    f"Could not start or attach to classic Outlook: {dispatch_error}"
                ) from dispatch_error

    @staticmethod
    def _safe_str_attr(item: Any, name: str) -> str:
        try:
            value = getattr(item, name)
        except Exception:
            return ""
        if value is None:
            return ""
        return str(value).strip()

    @staticmethod
    def _safe_optional_str_attr(item: Any, name: str) -> str | None:
        value = OutlookComClient._safe_str_attr(item, name)
        return value or None

    @staticmethod
    def _safe_bool_attr(item: Any, name: str) -> bool:
        try:
            return bool(getattr(item, name))
        except Exception:
            return False

    @staticmethod
    def _safe_datetime_attr(item: Any, name: str) -> datetime | None:
        try:
            value = getattr(item, name)
        except Exception:
            return None
        if isinstance(value, datetime):
            return value
        # pywintypes Time usually exposes timestamp() on recent pywin32.
        try:
            return datetime.fromtimestamp(value.timestamp())
        except Exception:
            return None


__all__ = ["OutlookComClient", "OutlookIntegrationError", "MAIL_ITEM_CLASS"]
