"""Sanitize Outlook mail bodies before speech output.

This module intentionally implements conservative, dependency-light cleaning.
It is not a full HTML mail renderer.  The goal is to make mail previews safe and
pleasant enough for local speech without logging or storing sensitive content.
"""

from __future__ import annotations

import html
import re

_TAG_RE = re.compile(r"<[^>]+>")
_SCRIPT_STYLE_RE = re.compile(
    r"<(script|style)\b[^>]*>.*?</\1>", re.IGNORECASE | re.DOTALL
)
_URL_RE = re.compile(r"https?://\S+|www\.\S+", re.IGNORECASE)
_WHITESPACE_RE = re.compile(r"[ \t\r\f\v]+")
_MULTI_NEWLINE_RE = re.compile(r"\n{3,}")
_QUOTE_MARKERS = (
    "-----Original Message-----",
    "----- Original Message -----",
    "差出人:",
    "送信者:",
    "From:",
    "Sent:",
    "On ",
)
_SIGNATURE_MARKERS = (
    "-- ",
    "——",
    "署名",
)


class MailBodySanitizer:
    """Prepare Outlook mail bodies for preview and speech."""

    def __init__(self, *, strip_urls: bool = True) -> None:
        self._strip_urls = strip_urls

    def sanitize(
        self,
        body: str | None,
        *,
        max_chars: int | None = None,
        cut_quotes: bool = True,
        cut_signature: bool = False,
    ) -> str:
        """Return cleaned plain text.

        Args:
            body: Raw Outlook body or HTML body.
            max_chars: Character limit. ``None`` or ``0`` means unlimited.
            cut_quotes: Whether to remove common quoted-reply sections.
            cut_signature: Whether to remove simple signature blocks.
        """
        text = body or ""
        text = self._html_to_text(text)
        if self._strip_urls:
            text = _URL_RE.sub("URL省略", text)
        text = self._normalize_whitespace(text)
        if cut_quotes:
            text = self._cut_at_markers(text, _QUOTE_MARKERS)
        if cut_signature:
            text = self._cut_at_markers(text, _SIGNATURE_MARKERS)
        text = text.strip()
        if max_chars and max_chars > 0 and len(text) > max_chars:
            return text[:max_chars].rstrip() + "…"
        return text

    def preview(self, body: str | None, *, max_chars: int) -> str:
        """Return a short body preview suitable for the first speech pass."""
        return self.sanitize(
            body,
            max_chars=max_chars,
            cut_quotes=True,
            cut_signature=True,
        )

    def full_body(self, body: str | None, *, max_chars: int | None = None) -> str:
        """Return a fuller body for optional second-pass speech."""
        return self.sanitize(
            body,
            max_chars=max_chars,
            cut_quotes=False,
            cut_signature=False,
        )

    @staticmethod
    def _html_to_text(text: str) -> str:
        # Heuristic: only strip tags if the text looks like HTML.
        if "<" in text and ">" in text:
            text = _SCRIPT_STYLE_RE.sub(" ", text)
            text = re.sub(r"<\s*br\s*/?>", "\n", text, flags=re.IGNORECASE)
            text = re.sub(r"</\s*p\s*>", "\n", text, flags=re.IGNORECASE)
            text = _TAG_RE.sub(" ", text)
        return html.unescape(text)

    @staticmethod
    def _normalize_whitespace(text: str) -> str:
        # Normalize per-line spaces while preserving a small amount of paragraph
        # structure for better speech chunking.
        text = text.replace("\r\n", "\n").replace("\r", "\n")
        lines = [_WHITESPACE_RE.sub(" ", line).strip() for line in text.split("\n")]
        text = "\n".join(line for line in lines if line)
        return _MULTI_NEWLINE_RE.sub("\n\n", text)

    @staticmethod
    def _cut_at_markers(text: str, markers: tuple[str, ...]) -> str:
        candidates = [text.find(marker) for marker in markers if text.find(marker) > 0]
        if not candidates:
            return text
        return text[: min(candidates)]


__all__ = ["MailBodySanitizer"]
