"""Plain Python models for the Outlook integration.

The Outlook integration must never pass COM objects across module or thread
boundaries.  The dataclasses in this module are the only objects the rest of
TextVoiceReader should consume.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime


@dataclass(frozen=True)
class OutlookMailSnapshot:
    """A COM-free snapshot of an Outlook mail item."""

    entry_id: str
    subject: str
    sender_name: str
    sender_email: str | None
    received_at: datetime | None
    body_preview: str
    full_body: str
    unread: bool

    @property
    def dedupe_key(self) -> str:
        """Return a stable key for duplicate detection.

        EntryID is preferred.  Some mock items or unsaved Outlook items may not
        have one, so fall back to a composite key that is good enough for a
        single monitoring session.
        """
        if self.entry_id:
            return self.entry_id
        received = self.received_at.isoformat() if self.received_at else ""
        return "|".join((received, self.sender_email or self.sender_name, self.subject))


__all__ = ["OutlookMailSnapshot"]
