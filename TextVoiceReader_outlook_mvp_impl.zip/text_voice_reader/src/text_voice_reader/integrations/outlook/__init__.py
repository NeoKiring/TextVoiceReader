"""Classic Outlook integration for TextVoiceReader."""

from text_voice_reader.integrations.outlook.com_client import (
    OutlookComClient,
    OutlookIntegrationError,
)
from text_voice_reader.integrations.outlook.formatter import (
    MailSpeechFormatter,
    MailSpeechFormatOptions,
)
from text_voice_reader.integrations.outlook.models import OutlookMailSnapshot
from text_voice_reader.integrations.outlook.monitor import OutlookMailMonitor
from text_voice_reader.integrations.outlook.sanitizer import MailBodySanitizer

__all__ = [
    "MailBodySanitizer",
    "MailSpeechFormatter",
    "MailSpeechFormatOptions",
    "OutlookComClient",
    "OutlookIntegrationError",
    "OutlookMailMonitor",
    "OutlookMailSnapshot",
]
