"""Polling monitor for classic Outlook new-mail detection."""

from __future__ import annotations

import threading
from collections.abc import Callable

from text_voice_reader.integrations.outlook.com_client import (
    OutlookComClient,
    OutlookIntegrationError,
)
from text_voice_reader.integrations.outlook.models import OutlookMailSnapshot
from text_voice_reader.logging_setup import get_logger

_log = get_logger(__name__)

MailCallback = Callable[[OutlookMailSnapshot], None]
ErrorCallback = Callable[[Exception], None]
StatusCallback = Callable[[str], None]


class OutlookMailMonitor:
    """Poll Outlook Inbox and report newly observed mail snapshots."""

    def __init__(
        self,
        client: OutlookComClient,
        *,
        poll_interval_seconds: int = 15,
        unread_only: bool = True,
        read_existing_on_startup: bool = False,
        ignore_empty_subject: bool = True,
        max_queue_size: int = 10,
        on_mail: MailCallback,
        on_error: ErrorCallback | None = None,
        on_status: StatusCallback | None = None,
    ) -> None:
        self._client = client
        self._poll_interval_seconds = max(5, int(poll_interval_seconds))
        self._unread_only = unread_only
        self._read_existing_on_startup = read_existing_on_startup
        self._ignore_empty_subject = ignore_empty_subject
        self._max_queue_size = max(1, int(max_queue_size))
        self._on_mail = on_mail
        self._on_error = on_error
        self._on_status = on_status
        self._seen: set[str] = set()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._lock = threading.Lock()

    @property
    def is_running(self) -> bool:
        thread = self._thread
        return thread is not None and thread.is_alive()

    def start(self) -> None:
        """Start monitoring in a background thread."""
        with self._lock:
            if self.is_running:
                return
            self._stop.clear()
            self._thread = threading.Thread(
                target=self._run,
                name="tvr-outlook-monitor",
                daemon=True,
            )
            self._thread.start()

    def stop(self, *, timeout: float = 2.0) -> None:
        """Request monitor stop and wait briefly."""
        self._stop.set()
        thread = self._thread
        if thread is not None and thread.is_alive():
            thread.join(timeout=timeout)

    def check_once(self) -> list[OutlookMailSnapshot]:
        """Poll once and return snapshots considered new."""
        mails = self._client.list_recent_messages(
            limit=self._max_queue_size,
            unread_only=self._unread_only,
            ignore_empty_subject=self._ignore_empty_subject,
        )
        new_mails: list[OutlookMailSnapshot] = []
        # The COM client returns newest first.  Read older first when multiple
        # mails arrived between polls.
        for mail in reversed(mails):
            key = mail.dedupe_key
            if key in self._seen:
                continue
            self._seen.add(key)
            new_mails.append(mail)
        return new_mails

    def _run(self) -> None:
        self._emit_status("Outlook監視を開始しました")
        try:
            if not self._read_existing_on_startup:
                for mail in self._client.list_recent_messages(
                    limit=self._max_queue_size,
                    unread_only=self._unread_only,
                    ignore_empty_subject=self._ignore_empty_subject,
                ):
                    self._seen.add(mail.dedupe_key)
                self._emit_status("起動時点の既存メールを既読扱いとしてスキップしました")
        except Exception as e:
            self._emit_error(e)

        while not self._stop.wait(self._poll_interval_seconds):
            try:
                for mail in self.check_once():
                    self._on_mail(mail)
            except OutlookIntegrationError as e:
                self._emit_error(e)
            except Exception as e:  # Defensive: monitoring should not crash GUI.
                self._emit_error(e)
        self._emit_status("Outlook監視を停止しました")

    def _emit_error(self, exc: Exception) -> None:
        _log.warning(f"Outlook monitor error: {exc}")
        if self._on_error is not None:
            self._on_error(exc)

    def _emit_status(self, message: str) -> None:
        _log.info(message)
        if self._on_status is not None:
            self._on_status(message)


__all__ = ["OutlookMailMonitor"]
