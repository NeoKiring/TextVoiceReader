"""Format Outlook mail snapshots into Japanese speech text."""

from __future__ import annotations

from dataclasses import dataclass

from text_voice_reader.integrations.outlook.models import OutlookMailSnapshot


@dataclass(frozen=True)
class MailSpeechFormatOptions:
    """Options controlling which mail fields are read aloud."""

    include_sender: bool = True
    include_subject: bool = True
    include_body_preview: bool = True


class MailSpeechFormatter:
    """Build speech strings for Outlook mail."""

    def __init__(self, options: MailSpeechFormatOptions | None = None) -> None:
        self._options = options or MailSpeechFormatOptions()

    def format_preview(self, mail: OutlookMailSnapshot) -> str:
        """Return the first-pass text read automatically for a new mail."""
        parts: list[str] = ["新着メールです。"]
        if self._options.include_sender:
            sender = mail.sender_name or mail.sender_email or "不明"
            parts.append(f"差出人は、{sender}さん。")
        if self._options.include_subject:
            subject = mail.subject or "件名なし"
            parts.append(f"件名は、{subject}。")
        if self._options.include_body_preview and mail.body_preview:
            parts.append(f"本文の冒頭は、{mail.body_preview}")
        return "".join(parts).strip()

    def format_full_body(self, mail: OutlookMailSnapshot) -> str:
        """Return the optional second-pass full-body speech text."""
        body = mail.full_body.strip()
        if not body:
            return "本文は空です。"
        subject = mail.subject.strip() or "件名なし"
        return f"メール本文を読み上げます。件名は、{subject}。本文、{body}"


__all__ = ["MailSpeechFormatter", "MailSpeechFormatOptions"]
