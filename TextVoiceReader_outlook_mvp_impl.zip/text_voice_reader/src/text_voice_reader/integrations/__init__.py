"""Optional local integrations for TextVoiceReader."""
