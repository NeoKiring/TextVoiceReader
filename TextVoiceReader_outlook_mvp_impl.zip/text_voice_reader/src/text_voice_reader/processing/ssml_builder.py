"""Build SAPI5-compatible SSML from plain text + prosody options.

SAPI5 accepts a relaxed subset of SSML wrapped in ``<speak>``. Supported tags
that we emit: ``<prosody pitch='...'>`` and ``<prosody rate='...'>`` and
``<break time='...ms'/>``.

Note: SAPI5 rate is an integer -10..+10 controlled via the speaker object,
not SSML rate. We only use SSML for pitch and optional pauses, keeping rate
control at the engine level.
"""

from __future__ import annotations

from xml.sax.saxutils import escape


def _pitch_to_ssml(pitch: int) -> str:
    """Convert -10..+10 pitch scale to SSML pitch attribute.

    SSML ``pitch`` accepts relative Hz or named values. We map:
        -10 -> "x-low"
        -5  -> "low"
         0  -> "medium"
        +5  -> "high"
        +10 -> "x-high"
    with linear interpolation for in-between values.
    """
    if pitch <= -8:
        return "x-low"
    if pitch <= -3:
        return "low"
    if pitch >= 8:
        return "x-high"
    if pitch >= 3:
        return "high"
    return "medium"


def build_ssml(text: str, *, pitch: int = 0, pause_ms: int = 0) -> str:
    """Wrap ``text`` in a SAPI5-compatible SSML envelope.

    Args:
        text: Text to speak (will be XML-escaped).
        pitch: Pitch scale -10..+10. 0 = no wrapping.
        pause_ms: Optional leading pause in milliseconds.

    Returns:
        SSML XML string suitable for ``SpVoice.Speak(..., SVSFIsXML)``.
    """
    escaped = escape(text)
    inner = escaped
    if pitch != 0:
        pv = _pitch_to_ssml(pitch)
        inner = f"<prosody pitch='{pv}'>{inner}</prosody>"
    if pause_ms > 0:
        inner = f"<silence msec='{int(pause_ms)}'/>{inner}"
    # SAPI5 uses its own XML dialect; <speak> is valid and stripped at runtime.
    return f"<speak version='1.0' xml:lang='ja-JP'>{inner}</speak>"


__all__ = ["build_ssml"]
