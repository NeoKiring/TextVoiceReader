"""Sentence splitter tuned for mixed Japanese/English text."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Iterable

# Primary sentence terminators: Japanese full stops, English periods,
# exclamation marks, and question marks.
# Periods are only treated as sentence boundaries when followed by whitespace,
# closing punctuation, or end-of-string so that common abbreviations like
# "e.g." / "U.S." / "Dr." are not split into tiny fragments.
_TERMINATORS = re.compile(
    r"(?<=[。！？!?])\s*|(?<=\.)(?=(?:\s+|[\"'”’）】\]\)]|$))\s*"
)
# Soft break candidates used when a chunk is still too long
_SOFT_BREAKS = re.compile(r"(?<=[、,;:])\s*")
# Characters considered "proper" sentence endings - we do NOT merge fragments
# that already end with one of these into the next, even if they are short.
_TERMINATOR_CHARS = "。！？!?."
# Common abbreviations that should stay attached to the following sentence part.
_EN_ABBREVIATIONS = {
    "dr.",
    "mr.",
    "mrs.",
    "ms.",
    "prof.",
    "sr.",
    "jr.",
    "st.",
    "vs.",
    "etc.",
    "e.g.",
    "i.e.",
    "u.s.",
    "u.k.",
}


@dataclass(frozen=True)
class Sentence:
    """A single sentence unit for TTS."""

    id: int
    text: str
    # Optional metadata (filled by downstream language detection)
    language: str | None = None


@dataclass
class SplitterOptions:
    """Tuning knobs for the splitter."""

    max_chars: int = 120
    merge_short_min: int = 8  # merge adjacent sub-threshold fragments


class SentenceSplitter:
    """Split text into sentence-sized chunks.

    The splitter first breaks on hard terminators (。！？! ? .), then recursively
    applies soft breaks (、, ; :) to over-long fragments, and finally hard-wraps
    anything still too long.

    Example:
        >>> s = SentenceSplitter(SplitterOptions(max_chars=30))
        >>> [x.text for x in s.split("こんにちは。元気ですか？")]
        ['こんにちは。', '元気ですか？']
    """

    def __init__(self, options: SplitterOptions | None = None) -> None:
        self._opts = options or SplitterOptions()

    def split(self, text: str) -> list[Sentence]:
        """Return a list of :class:`Sentence` objects in reading order."""
        if not text:
            return []
        hard = [s for s in _TERMINATORS.split(text) if s and s.strip()]
        hard = list(self._merge_english_abbreviations(hard))
        fragments: list[str] = []
        for frag in hard:
            fragments.extend(self._soft_split(frag))

        fragments = list(self._merge_short(fragments))
        return [
            Sentence(id=i, text=frag.strip())
            for i, frag in enumerate(fragments)
            if frag.strip()
        ]

    def _soft_split(self, text: str) -> list[str]:
        if len(text) <= self._opts.max_chars:
            return [text]
        parts = _SOFT_BREAKS.split(text)
        out: list[str] = []
        buf = ""
        for p in parts:
            if not p:
                continue
            if len(buf) + len(p) <= self._opts.max_chars:
                buf += p
            else:
                if buf:
                    out.append(buf)
                if len(p) > self._opts.max_chars:
                    out.extend(self._hard_wrap(p))
                    buf = ""
                else:
                    buf = p
        if buf:
            out.append(buf)
        return out

    def _hard_wrap(self, text: str) -> list[str]:
        n = self._opts.max_chars
        return [text[i : i + n] for i in range(0, len(text), n)]

    def _merge_english_abbreviations(self, fragments: Iterable[str]) -> Iterable[str]:
        """Keep common English abbreviations attached to the following text."""
        buf = ""
        for fragment in fragments:
            if buf:
                joiner = " " if buf.rstrip().endswith(".") else ""
                candidate = f"{buf}{joiner}{fragment.lstrip()}"
            else:
                candidate = fragment
            normalized = candidate.strip().lower()
            if normalized in _EN_ABBREVIATIONS:
                buf = candidate
                continue
            if buf:
                yield candidate
                buf = ""
            else:
                yield fragment
        if buf:
            yield buf

    def _merge_short(self, fragments: Iterable[str]) -> Iterable[str]:
        """Coalesce sub-threshold fragments with the previous one.

        Fragments whose buffered content already ends with a sentence terminator
        (句点/ピリオド/！/？) are never absorbed into the next: a terminator
        signals a complete thought, so we preserve its boundary even if short.
        """
        buf = ""
        for f in fragments:
            if not buf:
                buf = f
                continue
            buf_rstripped = buf.rstrip()
            buf_ended = buf_rstripped and buf_rstripped[-1] in _TERMINATOR_CHARS
            if (
                not buf_ended
                and len(f) < self._opts.merge_short_min
                and len(buf) + len(f) <= self._opts.max_chars
            ):
                buf += f
            else:
                yield buf
                buf = f
        if buf:
            yield buf


__all__ = ["Sentence", "SentenceSplitter", "SplitterOptions"]
