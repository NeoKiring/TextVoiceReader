"""Language detection wrapper around langid."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Literal

from text_voice_reader.logging_setup import get_logger

_log = get_logger(__name__)

Language = Literal["ja", "en", "mixed", "other"]

# Characters that are unambiguously Japanese
_JP_CHARS = re.compile(r"[\u3040-\u30ff\u3400-\u9fff\uf900-\ufaff]")
# Basic ASCII letters for English ratio
_EN_CHARS = re.compile(r"[A-Za-z]")


@dataclass(frozen=True)
class LanguageInfo:
    """Result of language detection."""

    language: Language
    ja_ratio: float
    en_ratio: float


class LanguageDetector:
    """Detect the primary language of a text.

    Priority:
        1. Script-based fast check (counts JP chars vs ASCII letters).
        2. ``langid`` fallback for edge cases (pure non-Latin non-Japanese).

    Example:
        >>> d = LanguageDetector()
        >>> d.detect("これはテストです").language
        'ja'
    """

    def __init__(self, mixed_threshold: float = 0.25) -> None:
        self._mixed_threshold = mixed_threshold

    def detect(self, text: str) -> LanguageInfo:
        """Classify ``text`` as ja / en / mixed / other."""
        if not text:
            return LanguageInfo(language="other", ja_ratio=0.0, en_ratio=0.0)

        total = len(text)
        jp = len(_JP_CHARS.findall(text))
        en = len(_EN_CHARS.findall(text))
        ja_r = jp / total
        en_r = en / total

        if ja_r > 0.05 and en_r > self._mixed_threshold:
            return LanguageInfo(language="mixed", ja_ratio=ja_r, en_ratio=en_r)
        if ja_r > 0.05:
            return LanguageInfo(language="ja", ja_ratio=ja_r, en_ratio=en_r)
        if en_r > 0.3:
            return LanguageInfo(language="en", ja_ratio=ja_r, en_ratio=en_r)

        # Fallback to langid for exotic content
        try:
            import langid  # type: ignore[import-untyped]

            lang, _ = langid.classify(text[:1000])
            mapped: Language
            if lang == "ja":
                mapped = "ja"
            elif lang == "en":
                mapped = "en"
            else:
                mapped = "other"
            return LanguageInfo(language=mapped, ja_ratio=ja_r, en_ratio=en_r)
        except Exception as e:  # pragma: no cover - optional fallback
            _log.debug(f"langid fallback failed: {e}")
            return LanguageInfo(language="other", ja_ratio=ja_r, en_ratio=en_r)


__all__ = ["Language", "LanguageDetector", "LanguageInfo"]
