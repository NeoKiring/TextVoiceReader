"""Text normalization pipeline.

The normalizer applies a sequence of idempotent transformations:

1. Unicode NFKC normalization (optional)
2. Control-character stripping
3. Whitespace collapsing
4. URL removal (configurable)
5. Emoji / pictograph removal
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass

_URL_RE = re.compile(r"https?://[^\s<>\"]+")
_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
_CTRL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
_MULTI_WS_RE = re.compile(r"[ \t\u00a0\u3000]+")
_MULTI_NL_RE = re.compile(r"\n{3,}")
# Common emoji / pictograph ranges
_EMOJI_RE = re.compile(
    "["
    "\U0001f300-\U0001f5ff"
    "\U0001f600-\U0001f64f"
    "\U0001f680-\U0001f6ff"
    "\U0001f700-\U0001f77f"
    "\U0001f780-\U0001f7ff"
    "\U0001f800-\U0001f8ff"
    "\U0001f900-\U0001f9ff"
    "\U0001fa00-\U0001fa6f"
    "\U0001fa70-\U0001faff"
    "\u2600-\u26ff"
    "\u2700-\u27bf"
    "]+",
    flags=re.UNICODE,
)


@dataclass
class NormalizerOptions:
    """Flags controlling which normalization steps are applied."""

    nfkc: bool = True
    strip_urls: bool = True
    strip_emails: bool = False
    strip_emojis: bool = True
    skip_empty_lines: bool = True
    url_replacement: str = ""  # e.g. "リンク省略"


class TextNormalizer:
    """Apply configured normalization steps to text.

    Example:
        >>> n = TextNormalizer(NormalizerOptions(strip_urls=True))
        >>> n.normalize("こんにちは https://example.com !")
        'こんにちは  !'
    """

    def __init__(self, options: NormalizerOptions | None = None) -> None:
        self._opts = options or NormalizerOptions()

    def normalize(self, text: str) -> str:
        """Run the full pipeline on ``text``."""
        if not text:
            return ""
        out = text

        if self._opts.nfkc:
            out = unicodedata.normalize("NFKC", out)

        out = _CTRL_RE.sub("", out)

        if self._opts.strip_urls:
            out = _URL_RE.sub(self._opts.url_replacement, out)

        if self._opts.strip_emails:
            out = _EMAIL_RE.sub("", out)

        if self._opts.strip_emojis:
            out = _EMOJI_RE.sub("", out)

        out = _MULTI_WS_RE.sub(" ", out)
        out = _MULTI_NL_RE.sub("\n\n", out)

        if self._opts.skip_empty_lines:
            out = "\n".join(line for line in out.splitlines() if line.strip())

        return out.strip()


__all__ = ["NormalizerOptions", "TextNormalizer"]
