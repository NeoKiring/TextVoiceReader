"""Bottom control panel: play/stop buttons and progress bar."""

from __future__ import annotations

from collections.abc import Callable

import customtkinter as ctk


class ControlPanel(ctk.CTkFrame):
    """Play / stop buttons plus a text progress indicator."""

    def __init__(
        self,
        master: ctk.CTkBaseClass,
        *,
        on_play: Callable[[], None],
        on_stop: Callable[[], None],
        **kwargs,
    ) -> None:
        super().__init__(master, **kwargs)

        self._on_play = on_play
        self._on_stop = on_stop

        self._btn_play = ctk.CTkButton(
            self, text="▶ 再生", width=100, command=self._handle_play
        )
        self._btn_stop = ctk.CTkButton(
            self, text="⏹ 停止", width=100, command=self._handle_stop, state="disabled"
        )

        self._btn_play.pack(side="left", padx=4, pady=8)
        self._btn_stop.pack(side="left", padx=4, pady=8)

        self._progress_var = ctk.StringVar(value="準備完了")
        self._progress = ctk.CTkLabel(self, textvariable=self._progress_var)
        self._progress.pack(side="right", padx=16)

        self._progress_bar = ctk.CTkProgressBar(self, width=180)
        self._progress_bar.set(0.0)
        self._progress_bar.pack(side="right", padx=8)

    # -----------------------------------------------------------------
    # Public API
    # -----------------------------------------------------------------

    def set_running(self, running: bool) -> None:
        """Toggle button enabled/disabled states based on run state."""
        if running:
            self._btn_play.configure(state="disabled")
            self._btn_stop.configure(state="normal")
        else:
            self._btn_play.configure(state="normal")
            self._btn_stop.configure(state="disabled")

    def set_progress(self, current: int, total: int, label: str = "") -> None:
        """Update the progress bar and text label."""
        if total <= 0:
            self._progress_bar.set(0.0)
            self._progress_var.set(label or "—")
            return
        self._progress_bar.set(current / total)
        suffix = f" - {label}" if label else ""
        self._progress_var.set(f"{current}/{total}{suffix}")

    def reset_progress(self) -> None:
        """Reset to zero/idle state."""
        self._progress_bar.set(0.0)
        self._progress_var.set("準備完了")

    # -----------------------------------------------------------------
    # Button handlers
    # -----------------------------------------------------------------

    def _handle_play(self) -> None:
        self._on_play()

    def _handle_stop(self) -> None:
        self._on_stop()


__all__ = ["ControlPanel"]
