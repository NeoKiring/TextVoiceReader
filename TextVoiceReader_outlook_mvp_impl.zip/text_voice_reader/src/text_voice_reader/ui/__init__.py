"""CustomTkinter-based UI layer."""

from __future__ import annotations

from importlib import import_module
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from text_voice_reader.ui.control_panel import ControlPanel
    from text_voice_reader.ui.log_panel import LogPanel
    from text_voice_reader.ui.main_window import MainWindow
    from text_voice_reader.ui.preview_panel import PreviewPanel
    from text_voice_reader.ui.settings_panel import SettingsPanel
    from text_voice_reader.ui.ui_bridge import UiBridge

__all__ = [
    "ControlPanel",
    "LogPanel",
    "MainWindow",
    "PreviewPanel",
    "SettingsPanel",
    "UiBridge",
]

_MODULE_BY_NAME = {
    "ControlPanel": "text_voice_reader.ui.control_panel",
    "LogPanel": "text_voice_reader.ui.log_panel",
    "MainWindow": "text_voice_reader.ui.main_window",
    "PreviewPanel": "text_voice_reader.ui.preview_panel",
    "SettingsPanel": "text_voice_reader.ui.settings_panel",
    "UiBridge": "text_voice_reader.ui.ui_bridge",
}


def __getattr__(name: str) -> Any:
    if name not in _MODULE_BY_NAME:
        raise AttributeError(name)
    module = import_module(_MODULE_BY_NAME[name])
    return getattr(module, name)
