"""Preview panel: editable text area with sentence-level highlighting."""

from __future__ import annotations

import customtkinter as ctk

from text_voice_reader.processing.splitter import Sentence


class PreviewPanel(ctk.CTkFrame):
    """Displays the loaded / edited text and highlights the active sentence."""

    def __init__(self, master: ctk.CTkBaseClass, **kwargs) -> None:
        super().__init__(master, **kwargs)

        self._label = ctk.CTkLabel(self, text="📄 テキストプレビュー", anchor="w")
        self._label.pack(fill="x", padx=8, pady=(8, 0))

        self._textbox = ctk.CTkTextbox(
            self,
            wrap="word",
            font=("Yu Gothic UI", 13),
        )
        self._textbox.pack(fill="both", expand=True, padx=8, pady=8)

        # Tk Text widget underneath customtkinter's textbox exposes tag_ methods
        self._inner = self._textbox._textbox  # type: ignore[attr-defined]
        self._inner.tag_config("active", background="#3a5b8c", foreground="#ffffff")
        self._sentence_ranges: dict[int, tuple[str, str]] = {}

    # -----------------------------------------------------------------
    # Public API
    # -----------------------------------------------------------------

    def set_text(self, text: str) -> None:
        """Replace the entire content with ``text``."""
        self._textbox.delete("1.0", "end")
        self._textbox.insert("1.0", text)
        self._sentence_ranges.clear()

    def get_text(self) -> str:
        """Return the current content of the text box (excluding trailing newline)."""
        return self._textbox.get("1.0", "end-1c")

    def set_sentences(self, sentences: list[Sentence]) -> None:
        """Replace content and record per-sentence text ranges for highlighting."""
        self._textbox.delete("1.0", "end")
        self._sentence_ranges.clear()
        cursor = "1.0"
        for s in sentences:
            start = cursor
            self._textbox.insert("end", s.text + "\n")
            end = self._inner.index("end-1c")
            self._sentence_ranges[s.id] = (start, end)
            cursor = end

    def highlight(self, sentence_id: int) -> None:
        """Visually mark the given sentence as the currently-speaking one."""
        self._inner.tag_remove("active", "1.0", "end")
        rng = self._sentence_ranges.get(sentence_id)
        if rng is None:
            return
        start, end = rng
        self._inner.tag_add("active", start, end)
        self._inner.see(start)

    def clear_highlight(self) -> None:
        """Remove any highlight markers."""
        self._inner.tag_remove("active", "1.0", "end")


__all__ = ["PreviewPanel"]
