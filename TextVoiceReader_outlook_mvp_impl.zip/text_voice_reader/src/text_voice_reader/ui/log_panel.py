"""Collapsible log panel at the bottom of the main window."""

from __future__ import annotations

import customtkinter as ctk
from loguru import logger

from text_voice_reader.ui.ui_bridge import UiBridge


class LogPanel(ctk.CTkFrame):
    """Shows recent log messages in a scrollable read-only text box.

    The panel is collapsible; clicking the header toggles visibility.
    """

    _MAX_LINES = 500

    def __init__(
        self,
        master: ctk.CTkBaseClass,
        *,
        bridge: UiBridge,
        **kwargs,
    ) -> None:
        super().__init__(master, **kwargs)
        self._bridge = bridge
        self._expanded = False
        self._is_destroyed = False

        self._toggle_btn = ctk.CTkButton(
            self,
            text="▸ ログ",
            anchor="w",
            command=self.toggle,
            fg_color="transparent",
            hover=True,
            height=24,
        )
        self._toggle_btn.pack(fill="x")

        self._body = ctk.CTkFrame(self, fg_color="transparent")
        self._textbox = ctk.CTkTextbox(
            self._body,
            height=120,
            font=("Consolas", 11),
            state="disabled",
            wrap="none",
        )
        self._textbox.pack(fill="both", expand=True, padx=4, pady=4)

        # Register loguru sink. The sink must not touch Tk widgets directly
        # because logger callbacks may execute on a non-UI thread.
        self._sink_id = logger.add(self._emit, level="INFO")

    # -----------------------------------------------------------------
    # Expand / collapse
    # -----------------------------------------------------------------

    def toggle(self) -> None:
        """Toggle visibility of the log body."""
        if self._expanded:
            self._body.pack_forget()
            self._toggle_btn.configure(text="▸ ログ")
        else:
            self._body.pack(fill="both", expand=True)
            self._toggle_btn.configure(text="▾ ログ")
        self._expanded = not self._expanded

    # -----------------------------------------------------------------
    # Loguru sink
    # -----------------------------------------------------------------

    def _emit(self, message) -> None:  # noqa: ANN001
        """Loguru sink callable. Receives a formatted message."""
        if self._is_destroyed:
            return
        self._bridge.post(self._append_text, str(message))

    def _append_text(self, text: str) -> None:
        """Append text on the Tk thread only."""
        if self._is_destroyed or not self.winfo_exists():
            return
        try:
            self._textbox.configure(state="normal")
            self._textbox.insert("end", text)
            # Trim to last N lines to avoid unbounded growth
            line_count = int(self._textbox.index("end-1c").split(".")[0])
            if line_count > self._MAX_LINES:
                delete_end = f"{line_count - self._MAX_LINES}.0"
                self._textbox.delete("1.0", delete_end)
            self._textbox.see("end")
            self._textbox.configure(state="disabled")
        except Exception:
            # UI is being torn down; swallow
            pass

    def destroy(self) -> None:  # type: ignore[override]
        self._is_destroyed = True
        try:
            logger.remove(self._sink_id)
        except Exception:
            pass
        super().destroy()


__all__ = ["LogPanel"]
