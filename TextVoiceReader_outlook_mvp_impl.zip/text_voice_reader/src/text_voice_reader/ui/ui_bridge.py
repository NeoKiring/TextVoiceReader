"""UI bridge: marshal callbacks from worker threads to the Tk main thread."""

from __future__ import annotations

import queue
import tkinter as tk
from collections.abc import Callable
from typing import Any

from text_voice_reader.logging_setup import get_logger

_log = get_logger(__name__)


class UiBridge:
    """Thread-safe bridge for posting callables to the Tk main loop.

    Worker threads call :meth:`post` to schedule a callable; the bridge
    invokes it on the Tk thread via ``after()``.

    Example:
        >>> bridge = UiBridge(root)  # doctest: +SKIP
        >>> bridge.post(label.config, text="done")  # doctest: +SKIP
    """

    def __init__(self, root: tk.Misc, poll_ms: int = 50) -> None:
        self._root = root
        self._q: queue.Queue[tuple[Callable[..., Any], tuple, dict]] = queue.Queue()
        self._poll_ms = poll_ms
        self._running = True
        self._after_id: str | None = None
        self._schedule_pump()

    def post(self, fn: Callable[..., Any], /, *args: Any, **kwargs: Any) -> None:
        """Schedule ``fn(*args, **kwargs)`` to run on the Tk thread."""
        if not self._running:
            return
        self._q.put((fn, args, kwargs))

    def shutdown(self) -> None:
        """Stop polling and drop any queued callbacks after this point."""
        self._running = False
        if self._after_id is not None:
            try:
                self._root.after_cancel(self._after_id)
            except Exception:
                pass
            self._after_id = None
        self._drain_queue()

    def _schedule_pump(self) -> None:
        if not self._running:
            return
        try:
            self._after_id = self._root.after(self._poll_ms, self._pump)
        except Exception:
            self._running = False
            self._after_id = None

    def _drain_queue(self) -> None:
        while True:
            try:
                self._q.get_nowait()
            except queue.Empty:
                break

    def _pump(self) -> None:
        self._after_id = None
        while True:
            try:
                fn, args, kwargs = self._q.get_nowait()
            except queue.Empty:
                break
            try:
                fn(*args, **kwargs)
            except Exception as e:
                _log.exception(f"UI callback failed: {e}")
        if self._running:
            self._schedule_pump()


__all__ = ["UiBridge"]
