"""Threading helpers and the shared StopToken primitive."""

from __future__ import annotations

import threading
from collections.abc import Callable
from typing import Any


class StopToken:
    """Cooperative cancellation token.

    Callers set this to request stop; workers poll :meth:`is_set` in loops.

    Example:
        >>> tok = StopToken()
        >>> tok.is_set()
        False
        >>> tok.set()
        >>> tok.is_set()
        True
    """

    __slots__ = ("_event",)

    def __init__(self) -> None:
        self._event = threading.Event()

    def set(self) -> None:
        """Request stop."""
        self._event.set()

    def clear(self) -> None:
        """Reset to unset state."""
        self._event.clear()

    def is_set(self) -> bool:
        """Return True if stop was requested."""
        return self._event.is_set()

    def wait(self, timeout: float | None = None) -> bool:
        """Block until set or timeout elapses."""
        return self._event.wait(timeout)


def run_in_thread(
    target: Callable[..., Any],
    *args: Any,
    daemon: bool = True,
    name: str | None = None,
    **kwargs: Any,
) -> threading.Thread:
    """Start ``target`` in a new thread and return it.

    Args:
        target: Callable to run.
        args: Positional args for target.
        daemon: Whether the thread should be daemonic.
        name: Optional thread name.
        kwargs: Keyword args for target.

    Returns:
        The started :class:`threading.Thread`.
    """
    t = threading.Thread(target=target, args=args, kwargs=kwargs, daemon=daemon, name=name)
    t.start()
    return t


__all__ = ["StopToken", "run_in_thread"]
