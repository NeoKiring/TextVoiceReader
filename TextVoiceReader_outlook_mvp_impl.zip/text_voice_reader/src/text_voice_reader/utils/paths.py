"""Filesystem / app-data path helpers."""

from __future__ import annotations

import os
import sys
from functools import lru_cache
from importlib.resources import files
from pathlib import Path
from tempfile import NamedTemporaryFile

APP_NAME = "TextVoiceReader"


@lru_cache(maxsize=1)
def get_package_root() -> Path:
    """Return the installed package root (where this file lives)."""
    return Path(__file__).resolve().parent.parent


@lru_cache(maxsize=1)
def get_packaged_config_text() -> str:
    """Read the packaged default config as UTF-8 text."""
    try:
        return files("text_voice_reader").joinpath("default.toml").read_text(
            encoding="utf-8"
        )
    except FileNotFoundError as exc:  # pragma: no cover - packaging error
        raise RuntimeError("Packaged default.toml is missing") from exc


@lru_cache(maxsize=1)
def get_package_config_path() -> Path:
    """Return a readable filesystem path for the packaged ``default.toml``.

    The default config is shipped inside the ``text_voice_reader`` package so it
    is available in normal installations, wheels, and source checkouts.
    """
    candidate = get_package_root() / "default.toml"
    if candidate.is_file():
        return candidate

    with NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        suffix="_text_voice_reader_default.toml",
        delete=False,
    ) as tmp:
        tmp.write(get_packaged_config_text())
        return Path(tmp.name)


def get_user_data_dir() -> Path:
    """Return platform-specific user data directory.

    Windows: %APPDATA%/TextVoiceReader
    Linux/macOS: ~/.config/TextVoiceReader
    """
    if sys.platform.startswith("win"):
        appdata = os.environ.get("APPDATA")
        if appdata:
            return Path(appdata) / APP_NAME
    # Linux/macOS fallback (dev)
    xdg = os.environ.get("XDG_CONFIG_HOME")
    base = Path(xdg) if xdg else Path.home() / ".config"
    return base / APP_NAME


def get_user_config_path() -> Path:
    """Return ``<user_data_dir>/config.toml``."""
    return get_user_data_dir() / "config.toml"


def get_user_log_dir() -> Path:
    """Return ``<user_data_dir>/logs``."""
    return get_user_data_dir() / "logs"


def resolve_user_path(raw: str) -> Path:
    """Expand ``~``, ``%VAR%`` and ``$VAR`` references to a concrete Path."""
    expanded = os.path.expandvars(os.path.expanduser(raw))
    return Path(expanded)


def ensure_dir(path: Path) -> Path:
    """``mkdir -p`` shortcut that returns ``path``."""
    path.mkdir(parents=True, exist_ok=True)
    return path


__all__ = [
    "APP_NAME",
    "get_package_root",
    "get_package_config_path",
    "get_packaged_config_text",
    "get_user_data_dir",
    "get_user_config_path",
    "get_user_log_dir",
    "resolve_user_path",
    "ensure_dir",
]
