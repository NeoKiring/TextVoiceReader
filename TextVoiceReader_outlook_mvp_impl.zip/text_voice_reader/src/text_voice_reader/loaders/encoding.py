"""Character encoding detection without external dependencies.

We use BOM detection plus a fixed list of candidate encodings that cover the
vast majority of Japanese/English text files encountered in practice:
UTF-8 (with/without BOM), UTF-16 LE/BE, Shift-JIS / CP932, EUC-JP.

The algorithm is deliberately simple - it tries each candidate and returns the
first one that decodes cleanly, preferring UTF variants when multiple succeed.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from text_voice_reader.logging_setup import get_logger

_log = get_logger(__name__)

# BOM magic numbers
_BOM_UTF8 = b"\xef\xbb\xbf"
_BOM_UTF16_LE = b"\xff\xfe"
_BOM_UTF16_BE = b"\xfe\xff"
_BOM_UTF32_LE = b"\xff\xfe\x00\x00"
_BOM_UTF32_BE = b"\x00\x00\xfe\xff"

# Ordered candidate encodings. UTF-8 first, then Japanese legacy.
_CANDIDATES: tuple[str, ...] = (
    "utf-8",
    "cp932",
    "shift_jis",
    "euc_jp",
    "utf-16-le",
    "utf-16-be",
    "iso-2022-jp",
)


@dataclass(frozen=True)
class DetectionResult:
    """Result of encoding detection."""

    encoding: str
    had_bom: bool
    sample_bytes: int


def detect_from_bom(data: bytes) -> str | None:
    """Return a decoder name if a BOM is found at the start of ``data``.

    BOM handling notes:
        * utf-8-sig strips the UTF-8 BOM on decode
        * utf-16 (without -le/-be) respects the BOM
        * utf-32 similarly
    """
    if data.startswith(_BOM_UTF32_LE) or data.startswith(_BOM_UTF32_BE):
        return "utf-32"
    if data.startswith(_BOM_UTF16_LE) or data.startswith(_BOM_UTF16_BE):
        return "utf-16"
    if data.startswith(_BOM_UTF8):
        return "utf-8-sig"
    return None


def detect_encoding(data: bytes, sample_size: int = 65536) -> DetectionResult:
    """Detect the encoding of ``data``.

    Args:
        data: Raw bytes to inspect.
        sample_size: How many leading bytes to use for trial decoding.

    Returns:
        A :class:`DetectionResult`.
    """
    bom_enc = detect_from_bom(data[:4])
    if bom_enc is not None:
        return DetectionResult(encoding=bom_enc, had_bom=True, sample_bytes=len(data))

    sample = data[:sample_size]
    for enc in _CANDIDATES:
        try:
            sample.decode(enc, errors="strict")
        except (UnicodeDecodeError, LookupError):
            continue
        # Prefer UTF-8 if it works perfectly
        _log.debug(f"detected encoding={enc} sample_len={len(sample)}")
        return DetectionResult(encoding=enc, had_bom=False, sample_bytes=len(sample))

    # Last resort - utf-8 with replace
    _log.warning("could not detect encoding; falling back to utf-8 with replacement")
    return DetectionResult(encoding="utf-8", had_bom=False, sample_bytes=len(sample))


def read_text_auto(path: Path) -> str:
    """Read a text file with automatic encoding detection.

    Args:
        path: File path.

    Returns:
        Decoded UTF-8 string.
    """
    raw = path.read_bytes()
    result = detect_encoding(raw)
    try:
        return raw.decode(result.encoding, errors="replace")
    except LookupError:
        return raw.decode("utf-8", errors="replace")


__all__ = [
    "DetectionResult",
    "detect_encoding",
    "detect_from_bom",
    "read_text_auto",
]
