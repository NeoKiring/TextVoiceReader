"""Outlook (.msg) loader using extract-msg."""

from __future__ import annotations

from pathlib import Path

from text_voice_reader.loaders.base import LoaderError
from text_voice_reader.logging_setup import get_logger

_log = get_logger(__name__)


class MsgLoader:
    """Loader for Outlook ``.msg`` email files."""

    supported_extensions: set[str] = {".msg"}

    def load(self, path: Path) -> str:
        if not path.is_file():
            raise LoaderError(f"File not found: {path}")

        try:
            import extract_msg  # type: ignore[import-untyped]
        except ImportError as e:
            raise LoaderError(
                "extract-msg is not installed. Run: pip install extract-msg"
            ) from e

        try:
            msg = extract_msg.Message(str(path))
        except Exception as e:
            raise LoaderError(f"Failed to open MSG {path}: {e}") from e

        try:
            subject = (msg.subject or "").strip()
            sender = (msg.sender or "").strip()
            to = (msg.to or "").strip()
            body = (msg.body or "").strip()

            parts = []
            if subject:
                parts.append(f"件名: {subject}")
            if sender:
                parts.append(f"差出人: {sender}")
            if to:
                parts.append(f"宛先: {to}")
            if body:
                parts.append("")  # blank line before body
                parts.append(body)

            _log.info(f"Loaded MSG file: subject='{subject}' body_len={len(body)}")
            return "\n".join(parts)
        finally:
            try:
                msg.close()
            except Exception:
                pass


__all__ = ["MsgLoader"]
