"""PDF loader using PyMuPDF (pymupdf / fitz)."""

from __future__ import annotations

import re
from pathlib import Path

from text_voice_reader.loaders.base import LoaderError
from text_voice_reader.logging_setup import get_logger

_log = get_logger(__name__)

# Lines that look like lone page numbers - common PDF noise
_PAGE_NUM_RE = re.compile(r"^\s*(?:page\s+)?\d+\s*(?:/\s*\d+)?\s*$", flags=re.IGNORECASE)


class PdfLoader:
    """Loader for ``.pdf`` files using PyMuPDF.

    Applies a best-effort heuristic for stripping headers/footers.
    """

    supported_extensions: set[str] = {".pdf"}

    def __init__(self, strip_headers: bool = True) -> None:
        self._strip_headers = strip_headers

    def load(self, path: Path) -> str:
        if not path.is_file():
            raise LoaderError(f"File not found: {path}")
        try:
            import fitz  # pymupdf
        except ImportError as e:
            raise LoaderError("pymupdf is not installed. Run: pip install pymupdf") from e

        try:
            doc = fitz.open(str(path))
        except Exception as e:
            raise LoaderError(f"Failed to open PDF {path}: {e}") from e

        pages: list[str] = []
        try:
            for page in doc:
                text = page.get_text("text") or ""
                if self._strip_headers:
                    text = self._remove_page_numbers(text)
                pages.append(text.strip())
        finally:
            doc.close()

        _log.info(f"Loaded {len(pages)} pages from {path.name}")
        return "\n\n".join(p for p in pages if p)

    @staticmethod
    def _remove_page_numbers(page_text: str) -> str:
        """Drop lines that look like lone page numbers."""
        lines = [ln for ln in page_text.splitlines() if not _PAGE_NUM_RE.match(ln)]
        return "\n".join(lines)


__all__ = ["PdfLoader"]
