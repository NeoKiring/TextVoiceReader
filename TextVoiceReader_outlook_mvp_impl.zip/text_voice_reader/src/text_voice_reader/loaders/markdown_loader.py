"""Markdown loader. Renders MD to HTML then strips tags to get readable text."""

from __future__ import annotations

import re
from pathlib import Path

import markdown
from bs4 import BeautifulSoup

from text_voice_reader.loaders.base import LoaderError
from text_voice_reader.loaders.encoding import read_text_auto

# Remove code fences, images, and URL autolinks for cleaner readout
_CODE_FENCE_RE = re.compile(r"```.*?```", flags=re.DOTALL)
_INLINE_CODE_RE = re.compile(r"`([^`]*)`")
_IMAGE_RE = re.compile(r"!\[[^\]]*\]\([^)]*\)")


class MarkdownLoader:
    """Loader for ``.md`` / ``.markdown`` files."""

    supported_extensions: set[str] = {".md", ".markdown", ".mdown"}

    def load(self, path: Path) -> str:
        if not path.is_file():
            raise LoaderError(f"File not found: {path}")
        try:
            raw = read_text_auto(path)
        except OSError as e:
            raise LoaderError(f"Failed to read {path}: {e}") from e

        # Pre-clean: drop code blocks and images for TTS readability
        cleaned = _CODE_FENCE_RE.sub("", raw)
        cleaned = _IMAGE_RE.sub("", cleaned)
        cleaned = _INLINE_CODE_RE.sub(r"\1", cleaned)

        html = markdown.markdown(
            cleaned,
            extensions=["extra", "sane_lists"],
            output_format="html5",
        )
        soup = BeautifulSoup(html, "html.parser")
        # Drop <pre><code> entirely
        for tag in soup.find_all(["pre", "code"]):
            tag.decompose()
        return soup.get_text(separator="\n")


__all__ = ["MarkdownLoader"]
