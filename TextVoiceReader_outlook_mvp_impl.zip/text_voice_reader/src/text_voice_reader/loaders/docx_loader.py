"""Microsoft Word (.docx) loader using python-docx with docx2txt fallback."""

from __future__ import annotations

from pathlib import Path

from text_voice_reader.loaders.base import LoaderError
from text_voice_reader.logging_setup import get_logger

_log = get_logger(__name__)


class DocxLoader:
    """Loader for ``.docx`` files.

    Extracts all paragraphs in document order. Falls back to ``docx2txt`` if
    ``python-docx`` fails (which can happen for certain malformed files).
    """

    supported_extensions: set[str] = {".docx"}

    def load(self, path: Path) -> str:
        if not path.is_file():
            raise LoaderError(f"File not found: {path}")

        # Primary path: python-docx
        try:
            import docx  # type: ignore[import-not-found]

            document = docx.Document(str(path))
            paragraphs = [p.text for p in document.paragraphs if p.text]

            # Also pull text from tables
            for table in document.tables:
                for row in table.rows:
                    cells = [c.text for c in row.cells if c.text]
                    if cells:
                        paragraphs.append(" ".join(cells))

            text = "\n".join(paragraphs)
            if text.strip():
                return text
            _log.info(f"python-docx extraction empty for {path.name}; trying docx2txt")
        except Exception as e:
            _log.warning(f"python-docx failed on {path}: {e}; trying docx2txt")

        # Fallback: docx2txt
        try:
            import docx2txt

            text = docx2txt.process(str(path)) or ""
            return text
        except Exception as e:
            raise LoaderError(f"Failed to extract text from {path}: {e}") from e


__all__ = ["DocxLoader"]
