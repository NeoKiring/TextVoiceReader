"""File-format loaders that produce plain UTF-8 text."""

from __future__ import annotations

from importlib import import_module
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from text_voice_reader.loaders.base import (
        LoaderError,
        TextLoader,
        TvrError,
        UnsupportedFormatError,
    )
    from text_voice_reader.loaders.csv_loader import CsvLoader
    from text_voice_reader.loaders.docx_loader import DocxLoader
    from text_voice_reader.loaders.encoding import DetectionResult, detect_encoding, read_text_auto
    from text_voice_reader.loaders.factory import LoaderFactory
    from text_voice_reader.loaders.html_loader import HtmlLoader
    from text_voice_reader.loaders.markdown_loader import MarkdownLoader
    from text_voice_reader.loaders.msg_loader import MsgLoader
    from text_voice_reader.loaders.pdf_loader import PdfLoader
    from text_voice_reader.loaders.pptx_loader import PptxLoader
    from text_voice_reader.loaders.txt_loader import TxtLoader

__all__ = [
    "CsvLoader",
    "DetectionResult",
    "DocxLoader",
    "HtmlLoader",
    "LoaderError",
    "LoaderFactory",
    "MarkdownLoader",
    "MsgLoader",
    "PdfLoader",
    "PptxLoader",
    "TextLoader",
    "TvrError",
    "TxtLoader",
    "UnsupportedFormatError",
    "detect_encoding",
    "read_text_auto",
]

_ATTR_SOURCES = {
    "CsvLoader": ("text_voice_reader.loaders.csv_loader", "CsvLoader"),
    "DetectionResult": ("text_voice_reader.loaders.encoding", "DetectionResult"),
    "DocxLoader": ("text_voice_reader.loaders.docx_loader", "DocxLoader"),
    "HtmlLoader": ("text_voice_reader.loaders.html_loader", "HtmlLoader"),
    "LoaderError": ("text_voice_reader.loaders.base", "LoaderError"),
    "LoaderFactory": ("text_voice_reader.loaders.factory", "LoaderFactory"),
    "MarkdownLoader": ("text_voice_reader.loaders.markdown_loader", "MarkdownLoader"),
    "MsgLoader": ("text_voice_reader.loaders.msg_loader", "MsgLoader"),
    "PdfLoader": ("text_voice_reader.loaders.pdf_loader", "PdfLoader"),
    "PptxLoader": ("text_voice_reader.loaders.pptx_loader", "PptxLoader"),
    "TextLoader": ("text_voice_reader.loaders.base", "TextLoader"),
    "TvrError": ("text_voice_reader.loaders.base", "TvrError"),
    "TxtLoader": ("text_voice_reader.loaders.txt_loader", "TxtLoader"),
    "UnsupportedFormatError": (
        "text_voice_reader.loaders.base",
        "UnsupportedFormatError",
    ),
    "detect_encoding": ("text_voice_reader.loaders.encoding", "detect_encoding"),
    "read_text_auto": ("text_voice_reader.loaders.encoding", "read_text_auto"),
}


def __getattr__(name: str) -> Any:
    if name not in _ATTR_SOURCES:
        raise AttributeError(name)
    module_name, attr_name = _ATTR_SOURCES[name]
    module = import_module(module_name)
    return getattr(module, attr_name)
