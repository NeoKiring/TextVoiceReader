"""CSV loader - flattens rows to readable text."""

from __future__ import annotations

import csv
import io
from pathlib import Path

from text_voice_reader.loaders.base import LoaderError
from text_voice_reader.loaders.encoding import detect_encoding


class CsvLoader:
    """Loader for ``.csv`` / ``.tsv`` files.

    Rows are joined with a separator so TTS reads them naturally.
    """

    supported_extensions: set[str] = {".csv", ".tsv"}

    def load(self, path: Path) -> str:
        if not path.is_file():
            raise LoaderError(f"File not found: {path}")

        raw = path.read_bytes()
        enc = detect_encoding(raw).encoding
        try:
            text = raw.decode(enc, errors="replace")
        except LookupError:
            text = raw.decode("utf-8", errors="replace")

        delimiter = "\t" if path.suffix.lower() == ".tsv" else ","
        reader = csv.reader(io.StringIO(text), delimiter=delimiter)
        lines: list[str] = []
        for row in reader:
            cleaned = [c.strip() for c in row if c and c.strip()]
            if cleaned:
                lines.append("、".join(cleaned))
        return "\n".join(lines)


__all__ = ["CsvLoader"]
