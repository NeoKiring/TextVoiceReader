"""HTML loader using BeautifulSoup."""

from __future__ import annotations

from pathlib import Path

from bs4 import BeautifulSoup

from text_voice_reader.loaders.base import LoaderError
from text_voice_reader.loaders.encoding import read_text_auto

# Tags whose text content should be dropped (not spoken)
_DROP_TAGS = ("script", "style", "noscript", "svg", "code", "pre")


class HtmlLoader:
    """Loader for ``.html`` / ``.htm`` / ``.xhtml`` files."""

    supported_extensions: set[str] = {".html", ".htm", ".xhtml"}

    def load(self, path: Path) -> str:
        if not path.is_file():
            raise LoaderError(f"File not found: {path}")
        try:
            raw = read_text_auto(path)
        except OSError as e:
            raise LoaderError(f"Failed to read {path}: {e}") from e

        soup = BeautifulSoup(raw, "html.parser")
        for tag_name in _DROP_TAGS:
            for tag in soup.find_all(tag_name):
                tag.decompose()

        # Prefer <body> text if present
        target = soup.body if soup.body else soup
        return target.get_text(separator="\n")


__all__ = ["HtmlLoader"]
