"""PowerPoint (.pptx) loader using python-pptx."""

from __future__ import annotations

from pathlib import Path

from text_voice_reader.loaders.base import LoaderError
from text_voice_reader.logging_setup import get_logger

_log = get_logger(__name__)


class PptxLoader:
    """Loader for ``.pptx`` files.

    Reads all slides in order, extracting text from shapes and speaker notes.
    """

    supported_extensions: set[str] = {".pptx"}

    def load(self, path: Path) -> str:
        if not path.is_file():
            raise LoaderError(f"File not found: {path}")

        try:
            from pptx import Presentation
        except ImportError as e:
            raise LoaderError(
                "python-pptx is not installed. Run: pip install python-pptx"
            ) from e

        try:
            prs = Presentation(str(path))
        except Exception as e:
            raise LoaderError(f"Failed to open PPTX {path}: {e}") from e

        parts: list[str] = []
        for idx, slide in enumerate(prs.slides, start=1):
            parts.append(f"--- Slide {idx} ---")
            slide_texts: list[str] = []
            for shape in slide.shapes:
                if shape.has_text_frame:
                    for para in shape.text_frame.paragraphs:
                        line = "".join(run.text for run in para.runs)
                        if line.strip():
                            slide_texts.append(line)
            if slide_texts:
                parts.append("\n".join(slide_texts))

            # Speaker notes
            if slide.has_notes_slide:
                notes = slide.notes_slide.notes_text_frame.text
                if notes and notes.strip():
                    parts.append(f"Notes: {notes.strip()}")

        _log.info(f"Loaded {len(prs.slides)} slides from {path.name}")
        return "\n\n".join(parts)


__all__ = ["PptxLoader"]
