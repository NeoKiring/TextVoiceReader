"""Text loader protocol and common types."""

from __future__ import annotations

from pathlib import Path
from typing import Protocol, runtime_checkable


class TvrError(Exception):
    """Base exception for TextVoiceReader."""


class LoaderError(TvrError):
    """Raised when a loader fails to read a file."""


class UnsupportedFormatError(LoaderError):
    """Raised when no loader matches the file extension."""


@runtime_checkable
class TextLoader(Protocol):
    """Protocol for all text loaders.

    Implementations take a file path and return plain text (UTF-8 str).
    They must not block on I/O for more than reasonable durations for the
    file size.

    Example:
        >>> class MyLoader:
        ...     supported_extensions = {".xyz"}
        ...     def load(self, path):
        ...         return path.read_text(encoding="utf-8")
    """

    supported_extensions: set[str]

    def load(self, path: Path) -> str:  # pragma: no cover - protocol
        """Read ``path`` and return its textual contents."""
        ...


__all__ = [
    "LoaderError",
    "TextLoader",
    "TvrError",
    "UnsupportedFormatError",
]
