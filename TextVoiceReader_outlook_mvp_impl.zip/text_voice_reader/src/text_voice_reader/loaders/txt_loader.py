"""Plain text file loader."""

from __future__ import annotations

from pathlib import Path

from text_voice_reader.loaders.base import LoaderError
from text_voice_reader.loaders.encoding import read_text_auto


class TxtLoader:
    """Loader for .txt / .log / generic text files with auto-detected encoding."""

    supported_extensions: set[str] = {".txt", ".log", ".text"}

    def load(self, path: Path) -> str:
        """Read ``path`` as auto-detected encoding and return text."""
        if not path.is_file():
            raise LoaderError(f"File not found: {path}")
        try:
            return read_text_auto(path)
        except OSError as e:
            raise LoaderError(f"Failed to read {path}: {e}") from e


__all__ = ["TxtLoader"]
