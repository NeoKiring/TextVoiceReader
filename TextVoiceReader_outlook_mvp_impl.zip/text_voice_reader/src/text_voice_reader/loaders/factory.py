"""Factory that maps file extensions to loader instances."""

from __future__ import annotations

from pathlib import Path

from text_voice_reader.loaders.base import TextLoader, UnsupportedFormatError
from text_voice_reader.loaders.csv_loader import CsvLoader
from text_voice_reader.loaders.docx_loader import DocxLoader
from text_voice_reader.loaders.html_loader import HtmlLoader
from text_voice_reader.loaders.markdown_loader import MarkdownLoader
from text_voice_reader.loaders.msg_loader import MsgLoader
from text_voice_reader.loaders.pdf_loader import PdfLoader
from text_voice_reader.loaders.pptx_loader import PptxLoader
from text_voice_reader.loaders.txt_loader import TxtLoader


class LoaderFactory:
    """Resolve the appropriate :class:`TextLoader` for a file path.

    Custom loaders can be registered via :meth:`register`, allowing consumers
    to extend supported formats without editing this module.

    Example:
        >>> factory = LoaderFactory()
        >>> loader = factory.resolve(Path("memo.txt"))
        >>> isinstance(loader, TxtLoader)
        True
    """

    def __init__(self, pdf_strip_headers: bool = True) -> None:
        # Instantiate built-in loaders. Stateless enough to share.
        self._loaders: list[TextLoader] = [
            TxtLoader(),
            MarkdownLoader(),
            PdfLoader(strip_headers=pdf_strip_headers),
            DocxLoader(),
            PptxLoader(),
            HtmlLoader(),
            CsvLoader(),
            MsgLoader(),
        ]
        self._ext_map: dict[str, TextLoader] = {}
        for loader in self._loaders:
            for ext in loader.supported_extensions:
                self._ext_map[ext.lower()] = loader

    def register(self, loader: TextLoader) -> None:
        """Register a custom loader. Its extensions override existing mappings."""
        self._loaders.append(loader)
        for ext in loader.supported_extensions:
            self._ext_map[ext.lower()] = loader

    def resolve(self, path: Path) -> TextLoader:
        """Return the loader responsible for ``path``.

        Raises:
            UnsupportedFormatError: if no registered loader handles the extension.
        """
        ext = path.suffix.lower()
        if ext not in self._ext_map:
            raise UnsupportedFormatError(
                f"No loader registered for extension '{ext}' "
                f"(supported: {sorted(self.supported_extensions())})"
            )
        return self._ext_map[ext]

    def supported_extensions(self) -> set[str]:
        """Return the full set of supported file extensions."""
        return set(self._ext_map.keys())


__all__ = ["LoaderFactory"]
