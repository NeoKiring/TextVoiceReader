# Architecture

## レイヤー図

```
┌──────────────────────────────────────────────────┐
│  Presentation Layer                              │
│    ui/main_window.py                             │
│    ui/preview_panel.py / settings_panel.py       │
│    ui/control_panel.py / log_panel.py            │
│    ui/ui_bridge.py  ← Queue + after() thread bridge
├──────────────────────────────────────────────────┤
│  Application Layer                               │
│    orchestrator/app_orchestrator.py              │
│    app.py  ← CLI argparse + GUI launcher         │
├──────────────────────────────────────────────────┤
│  Domain Layer (Protocols + Values)               │
│    loaders/base.py   → TextLoader Protocol       │
│    tts/base.py       → TtsEngine / SpeechHandle  │
│    tts/options.py    → VoiceInfo / SynthesisOpts │
│    processing/{normalizer,splitter,lang_detector}│
├──────────────────────────────────────────────────┤
│  Infrastructure Layer                            │
│    tts/sapi5_engine.py   ← pywin32 COM           │
│    tts/onnx_engine.py    ← Phase 5 stub          │
│    audio/wav_exporter.py ← stdlib wave           │
│    audio/player.py       ← winsound              │
│    audio/hybrid_sink.py  ← combines all of above │
│    loaders/{txt,md,pdf,docx,pptx,html,csv,msg}   │
└──────────────────────────────────────────────────┘
```

## データフロー

```
User picks file
  → LoaderFactory.resolve(path.suffix)
  → loader.load(path)                   [bytes → str]
  → TextNormalizer.normalize(raw)       [NFKC, ws, urls]
  → SentenceSplitter.split(normalized)  [→ list[Sentence]]
  → LanguageDetector.detect(sentence)   [annotate each]

User presses ▶ Play
  → AppOrchestrator.run(sentences, opts)
     (worker thread)
     for each sentence:
        HybridSink.consume(sentence.text, opts, stop_token)
           ├ engine.synthesize_to_file(temp.wav)    [1 synthesis]
           ├ exporter.append(temp.wav)              [saved to combined.wav]
           └ player.play_sync(temp.wav)             [played via winsound]
        progress_cb(cur, total, sentence)
           └ bridge.post(preview.highlight, ...)    [back to Tk main]
```

## 主要な設計判断

### 1. Protocol ベースの抽象化
`TtsEngine` / `TextLoader` / `SpeechHandle` を `typing.Protocol` として定義し、
実装クラス（`Sapi5Engine`, `TxtLoader`, `_Sapi5Handle` 等）は名目的継承なしで適合します。
これにより、テストでのモックが容易で、将来 ONNX や WebTTS を追加する際も
`LoaderFactory.register()` / `create_engine()` だけ拡張すれば済みます。

### 2. ハイブリッド出力方式
「再生しながら WAV に保存」を達成する最も簡潔な方法として、
**文ごとに1回だけ SAPI5 で合成 → その temp WAV を
(a) winsound で再生、(b) stdlib `wave` で結合ファイルに追記** という設計を採用しました。
SAPI5 本体の二重 `Speak` や `SpAudioPlug` を避け、依存関係を最小化しつつ
最終 WAV と再生内容が完全に一致する保証が得られます。

### 3. スレッド境界の明確化
合成・再生・WAV連結はすべて **ワーカースレッド** で実行し、
**Tk UI は必ずメインスレッドのみ**で更新します。橋渡しは `UiBridge` が
`queue.Queue + root.after()` パターンで行います。これにより長文処理中も
UI はレスポンシブに保たれます。

### 4. 協調的キャンセル
長時間処理は `StopToken` を受け取り、各イテレーション先頭で `is_set()` を
確認します。途中まで合成した WAV は破棄せず、そこまでの内容が保存された
状態で終了します（データロス回避）。

### 5. pywin32 遅延ロード
`sapi5_engine.py` のトップレベルでは `win32com.client` を import しません。
`_require_win32()` 内で遅延ロードし、非 Windows 環境でもモジュールの
インポート自体は成功します。これによりテストではモックで上書きできます。

### 6. 文字コード自己検出（chardet 不使用）
許可リストに `chardet` が無いため、BOM 検出 + 候補エンコーディング順試行
（UTF-8, CP932, Shift-JIS, EUC-JP, UTF-16 LE/BE, ISO-2022-JP）で自己判定します。
日本語 Windows 環境で実用上十分な精度が得られます。

### 7. 設定の 3 層マージ
`config/default.toml` (package) + `%APPDATA%/.../config.toml` (user) + `TVR_*` 環境変数
の順でマージされ、`pydantic-settings` の型検証を通ります。
UI の「設定を保存」ボタンは (2) に書き戻します。

## 拡張ポイント

| やりたいこと | 触るファイル |
|------------|------------|
| 新しいファイル形式対応 | `loaders/xyz_loader.py` + `factory.py` |
| 新しい TTS エンジン | `tts/xyz_engine.py` + `tts/__init__.py::create_engine` |
| 新しい UI パネル | `ui/xyz_panel.py` + `ui/main_window.py` で配置 |
| 正規化ルール追加 | `processing/normalizer.py` |
| 配布形式を変える | `build/build_exe.py` |

## 依存関係の方向

- Presentation → Application → Domain ← Infrastructure
- Domain は他のどのレイヤーにも依存しない
- Infrastructure は Domain の Protocol を実装するのみ

## Outlook integration architecture

The Outlook integration is isolated under `src/text_voice_reader/integrations/outlook/`.

Key rules:

- `com_client.py` is the only module that talks to Outlook COM.
- Public COM client methods initialize and uninitialize COM for the current thread.
- Outlook COM objects are converted to `OutlookMailSnapshot` dataclasses before leaving `com_client.py`.
- `monitor.py` runs polling in a background thread and reports snapshots through callbacks.
- GUI work, including the full-body confirmation dialog, is marshalled to the Tk main thread through `UiBridge`.
- Outlook mail speech uses the existing orchestrator but forces `play=True` and `save_wav=False` to avoid saving sensitive mail content by default.

The full-body flow is intentionally two-step:

1. Read sender / subject / body preview.
2. After preview speech completes, show a Tk confirmation dialog.
3. Read the full body only when the user selects Yes.
