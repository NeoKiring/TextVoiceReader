# Developer Guide

開発・拡張・貢献のための手引き。ユーザー向け情報は [`user_guide.md`](user_guide.md) を参照してください。

---

## 開発環境のセットアップ

### 前提条件

- Python 3.11 以上（3.12 推奨）
- Windows 10/11 (x64) — 実行時は SAPI5 が必要ですが、テスト/リンターは他OSでも動きます
- Git

### 初回セットアップ

```powershell
git clone <repo_url> text_voice_reader
cd text_voice_reader

python -m venv .venv
.venv\Scripts\activate

pip install -U pip wheel
pip install -e ".[dev]"
```

### VSCode 推奨設定

`.vscode/settings.json`（未コミット）:
```json
{
    "python.defaultInterpreterPath": ".venv/Scripts/python.exe",
    "python.testing.pytestEnabled": true,
    "python.testing.pytestArgs": ["tests"],
    "editor.formatOnSave": true,
    "[python]": { "editor.defaultFormatter": "ms-python.black-formatter" }
}
```

---

## プロジェクト構成

```
src/text_voice_reader/
├── app.py                  # エントリ（argparse + GUI/CLI ディスパッチ）
├── config.py               # pydantic-settings 設定
├── logging_setup.py        # loguru 初期化
├── loaders/                # 8形式のファイルローダー + Factory
├── processing/             # 正規化・分割・言語判定・SSML生成
├── tts/                    # TtsEngine Protocol + SAPI5/ONNX 実装
├── audio/                  # Player / WavExporter / HybridSink
├── orchestrator/           # 全体調整
├── ui/                     # CustomTkinter UI
└── utils/                  # paths / threading
```

### レイヤー責務（繰り返し）

| レイヤー | 触れてよいもの | 触れてはいけないもの |
|---------|---------------|---------------------|
| Presentation (ui) | Orchestrator, Domain types | SAPI5 / win32com を直接 |
| Application (orchestrator, app) | Domain Protocols | UI モジュール |
| Domain (base, options, splitter, etc.) | Python stdlib のみ | Infrastructure を直接 |
| Infrastructure (sapi5_engine, loaders/*) | 外部ライブラリ、OS API | UI / Orchestrator |

逆方向の依存は許されません。ruff の import 順チェックで検出できます。

---

## 拡張: 新しい Loader を追加する

例として `.epub` 対応を追加する場合:

### Step 1. Loaderクラスを作成

```python
# src/text_voice_reader/loaders/epub_loader.py
from __future__ import annotations

from pathlib import Path

from text_voice_reader.loaders.base import LoaderError


class EpubLoader:
    """Loader for .epub ebooks."""

    supported_extensions: set[str] = {".epub"}

    def load(self, path: Path) -> str:
        if not path.is_file():
            raise LoaderError(f"File not found: {path}")
        # ... EPUB解析ロジック（ebooklib 等は許可リスト外なので zipfile + BeautifulSoup で自前実装）
        return extracted_text


__all__ = ["EpubLoader"]
```

### Step 2. Factoryに登録

`loaders/factory.py` の `__init__` で `self._loaders.append(EpubLoader())` するか、
ランタイムで `factory.register(EpubLoader())` してもOK。

### Step 3. `loaders/__init__.py` に再エクスポート

```python
from text_voice_reader.loaders.epub_loader import EpubLoader
# __all__ に "EpubLoader" を追加
```

### Step 4. テストを書く

```python
# tests/unit/test_loaders.py に追加
def test_epub_loader_reads_fixture():
    loader = EpubLoader()
    text = loader.load(FIXTURES / "sample.epub")
    assert len(text) > 0
```

`tests/fixtures/sample.epub` を用意するのも忘れずに。

---

## 拡張: 新しい TTS エンジンを追加する

例として `edge-tts`（許可リスト外ですが、仮に使えると仮定）追加の場合:

### Step 1. エンジンクラスを作成

```python
# src/text_voice_reader/tts/edge_engine.py
from __future__ import annotations

from pathlib import Path

from text_voice_reader.tts.base import SpeechHandle, TtsError
from text_voice_reader.tts.options import SynthesisOptions, VoiceInfo


class _EdgeHandle:
    # SpeechHandle プロトコルに適合する実装
    def wait(self, timeout_ms: int = -1) -> None: ...
    def stop(self) -> None: ...
    def pause(self) -> None: ...
    def resume(self) -> None: ...
    @property
    def is_done(self) -> bool: ...


class EdgeTtsEngine:
    name: str = "edge"

    def list_voices(self) -> list[VoiceInfo]: ...
    def synthesize_to_file(self, text: str, wav_path: Path, opts: SynthesisOptions) -> None: ...
    def speak_async(self, text: str, opts: SynthesisOptions) -> SpeechHandle:
        return _EdgeHandle()


__all__ = ["EdgeTtsEngine"]
```

### Step 2. `tts/__init__.py::create_engine` に分岐を追加

```python
if lowered == "edge":
    from text_voice_reader.tts.edge_engine import EdgeTtsEngine
    return EdgeTtsEngine()
```

### Step 3. `config.py::TtsSection.engine` の Literal を拡張

```python
engine: Literal["sapi5", "onnx", "edge"] = "sapi5"
```

### Step 4. テストを追加（モックで）

`test_sapi5_engine.py` と同様のパターンで、外部SDKをモック化してユニットテストを書きます。

---

## コーディング規約

### スタイル

- **black** (line 100) でフォーマット: `black .`
- **ruff** で Lint: `ruff check .`
- import は `from __future__ import annotations` を必ず冒頭に
- 型ヒント必須。`typing.Any` は最後の手段
- docstring は Google スタイル、public クラスには例を含める

### 命名

| 種類 | スタイル | 例 |
|------|---------|-----|
| 関数・変数 | snake_case | `load_config`, `sentence_id` |
| クラス | PascalCase | `Sapi5Engine` |
| 定数 | UPPER_SNAKE_CASE | `SVSF_ASYNC` |
| プライベート | 先頭 `_` | `_select_voice`, `_opts` |
| モジュール | snake_case | `hybrid_sink.py` |

### 例外

独自階層を使うこと:

```
TvrError
├── LoaderError
│   └── UnsupportedFormatError
├── TtsError
└── AudioError
```

`except: pass` 禁止。最低でも `except Exception as e: _log.exception(e)` でログ残す。

### サイズ目安

- 1関数 40行以内
- 1クラス 300行以内
- 1ファイル 500行以内

超える場合は分割を検討。

---

## テスト

### 実行

```powershell
pytest                         # 全テスト
pytest tests/unit              # ユニットのみ
pytest -m "not sapi5"          # SAPI5が必要なE2Eを除外
pytest -k test_splitter        # 名前でフィルタ
pytest --cov=src/text_voice_reader --cov-report=html
# coverage レポート: htmlcov/index.html
```

### 書き方のポイント

1. **SAPI5 / COMを直接使うテストは `@pytest.mark.sapi5`** を付ける。CIでは `pytest -m "not sapi5"` で除外できる。
2. **Infrastructure層はモック**。`test_sapi5_engine.py` が参考になる（`_require_win32` を monkeypatch でモックに差し替える）。
3. **Domain層は純粋関数的**なので、直接ユニットテスト可能。
4. **Fixtureは `tests/fixtures/`** に置く。バイナリ形式（pdf/docx/pptx）もここに。
5. **Tkinter を実際に起動するテストは基本的に書かない**（CIで不安定）。UIの主要ロジックは極力 Orchestrator に寄せて、そちらをテストする。

---

## ロギング

```python
from text_voice_reader.logging_setup import get_logger
_log = get_logger(__name__)

_log.info("Voice selected: {name}", name=voice.name)
_log.warning("Failed to apply prosody: {}", err)
_log.exception("Unexpected error")  # stack trace 付き
```

- `DEBUG`: 内部状態、トレース用
- `INFO`: 正常系の主要イベント
- `WARNING`: 想定内の異常（fallback 発動、など）
- `ERROR`: ユーザーに通知すべき失敗
- `CRITICAL`: 続行不能な致命的エラー

UI層ではユーザーに通知すべきエラーは `messagebox.showerror` で、同時にログにも残します。

---

## リリース手順

1. `pyproject.toml` の `version` を更新
2. `src/text_voice_reader/__init__.py::__version__` を同じ値に更新
3. `CHANGELOG.md` を更新（未コミット / 任意）
4. `pytest -q` がすべて green
5. `ruff check .` と `black --check .` が green
6. `python build/build_exe.py --mode pyinstaller` で exe をビルド
7. クリーン Windows 環境で動作確認
8. Git tag: `git tag v0.x.y && git push --tags`

---

## よくある開発上の落とし穴

| 症状 | 原因 | 対処 |
|------|------|------|
| import すると pywin32 エラー | トップレベルで `import win32com.client` している | `_require_win32()` 経由で遅延ロード |
| テストが Windows以外で落ちる | プラットフォーム判定なし | `@pytest.mark.sapi5` を付ける |
| UI が固まる | 合成処理をメインスレッドで実行 | `run_in_thread()` でワーカーへ |
| UIから Tk 更新で例外 | ワーカーから直接 widget.config() | `UiBridge.post()` 経由で |
| WAV連結でフォーマット不一致 | 合成ごとにサンプルレートがずれる | `SynthesisOptions.sample_rate` を統一 |
| COM リソースリーク | SpFileStream の Close忘れ | `try/finally` で `Close()` |

---

## 貢献する前のチェックリスト

- [ ] `pytest -m "not sapi5"` が green
- [ ] `ruff check .` が green
- [ ] `black --check .` が green
- [ ] 新機能には対応テストを追加
- [ ] 公開APIには docstring と使用例
- [ ] README / user_guide / architecture / developer_guide の更新が必要なら実施
- [ ] コミットメッセージは Conventional Commits 形式推奨 (`feat:`, `fix:`, `docs:`, `test:` 等)

---

## リファレンス

- SAPI5 公式: https://learn.microsoft.com/en-us/previous-versions/windows/desktop/ms717077(v=vs.85)
- pywin32: https://github.com/mhammond/pywin32
- CustomTkinter: https://customtkinter.tomschimansky.com/
- loguru: https://loguru.readthedocs.io/
- pydantic-settings: https://docs.pydantic.dev/latest/concepts/pydantic_settings/
