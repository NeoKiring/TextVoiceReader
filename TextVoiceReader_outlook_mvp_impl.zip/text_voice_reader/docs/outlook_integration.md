# Outlook 新着メール読み上げ機能

## 対象範囲

この機能は初期実装として **classic Outlook for Windows + Outlook COM + ローカル処理 + ポーリング方式** を対象にします。

対象外:

- new Outlook for Windows
- Outlook Web
- Microsoft Graph / OAuth / Entra ID
- Exchange Online 直接連携
- 添付ファイル読み上げ
- メール返信 / 削除 / 移動

## プライバシー方針

- 既定では `[outlook].enabled = false` です。
- ユーザーが明示的に有効化するまで Outlook COM へアクセスしません。
- メール本文はログへ出しません。
- Outlook メール読み上げでは、既定の WAV 保存設定に関係なく `save_wav = false` を強制します。
- 本文冒頭だけを自動読み上げし、その後、ユーザーが Yes を選択した場合のみ本文全文を読み上げます。

## 設定

`default.toml` / ユーザー設定ファイルに `[outlook]` セクションを持ちます。

```toml
[outlook]
enabled = false
mode = "polling"
poll_interval_seconds = 15
folder = "Inbox"
unread_only = true
read_existing_on_startup = false
mark_as_read_after_speaking = false
allow_start_outlook = false

include_sender = true
include_subject = true
include_body_preview = true
body_preview_max_chars = 300

ask_before_full_body = true
full_body_max_chars = 0

ignore_empty_subject = true
ignore_sender_patterns = []
include_sender_patterns = []
max_queue_size = 10
```

`full_body_max_chars = 0` は明示上限なしを意味します。長文メールの読み上げ時間を制限したい場合は正の値を設定してください。

## 動作概要

1. Outlook monitor thread が一定間隔で Inbox を確認します。
2. Outlook COM の MailItem は `OutlookMailSnapshot` dataclass に変換され、COM object は外へ出しません。
3. Tk main thread に通知し、本文冒頭の読み上げを開始します。
4. 本文冒頭の読み上げ完了後、Tk main thread 上で `messagebox.askyesno()` を表示します。
5. Yes の場合のみ全文を読み上げます。

## 手動確認

最初に Spike script で Outlook COM 接続を確認してください。

```powershell
python scripts\spike_outlook_read_inbox.py
```

GUI で確認する場合:

1. classic Outlook を起動します。
2. `python -m text_voice_reader` で GUI を起動します。
3. 右側の Outlook セクションで「新着メールを読み上げる」を ON にします。
4. 必要に応じて「今すぐチェック」を押します。
5. 本文冒頭の読み上げ後、「本文全文を読み上げますか？」で Yes を選択します。

## 実装上の禁止事項

- Outlook COM object を Tk main thread へ渡さない
- Outlook COM object を SAPI5 speech thread へ渡さない
- MailItem を queue に積まない
- monitor thread から Tk widget を直接操作しない
- メール本文をログ出力しない
