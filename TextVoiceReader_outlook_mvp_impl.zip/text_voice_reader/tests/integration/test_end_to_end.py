"""End-to-end integration test.

Marked with ``@pytest.mark.sapi5`` so it is skipped on non-Windows CI.
When run on Windows with a SAPI5 voice installed, it verifies the full
pipeline: load file → normalize → split → synthesize → save WAV.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

from text_voice_reader.config import AppConfig, OutputSection, ProcessingSection, TtsSection
from text_voice_reader.orchestrator import AppOrchestrator

FIXTURES = Path(__file__).parent.parent / "fixtures"

pytestmark = pytest.mark.sapi5


@pytest.mark.skipif(not sys.platform.startswith("win"), reason="SAPI5 is Windows-only")
def test_end_to_end_txt_to_wav(tmp_path: Path):
    cfg = AppConfig(
        tts=TtsSection(engine="sapi5", voice="", rate=0, volume=70),
        output=OutputSection(
            play=False, save_wav=True, save_dir=str(tmp_path), wav_sample_rate=22050
        ),
        processing=ProcessingSection(),
    )
    orch = AppOrchestrator(cfg)

    sentences = orch.load_and_prepare(FIXTURES / "sample.txt")
    assert len(sentences) > 0

    result = orch.run(sentences, play=False, save_wav=True, source_name="sample")
    assert result.output_wav is not None
    assert result.output_wav.is_file()
    assert result.output_wav.stat().st_size > 100  # non-trivial wav
