from __future__ import annotations

from text_voice_reader.integrations.outlook.com_client import MAIL_ITEM_CLASS, OutlookComClient


class _FakeMail:
    Class = MAIL_ITEM_CLASS
    EntryID = "entry-1"
    Subject = "件名"
    SenderName = "送信者"
    SenderEmailAddress = "sender@example.com"
    ReceivedTime = None
    Body = "本文です。"
    HTMLBody = ""
    UnRead = True


class _FakeMeeting:
    Class = 26


def test_extract_mail_snapshot_returns_plain_dataclass():
    client = OutlookComClient(body_preview_max_chars=5)

    snapshot = client.extract_mail_snapshot(_FakeMail())

    assert snapshot is not None
    assert snapshot.entry_id == "entry-1"
    assert snapshot.subject == "件名"
    assert snapshot.body_preview == "本文です。"
    assert snapshot.full_body == "本文です。"
    assert snapshot.unread is True


def test_extract_mail_snapshot_skips_non_mail_item():
    client = OutlookComClient()

    assert client.extract_mail_snapshot(_FakeMeeting()) is None
