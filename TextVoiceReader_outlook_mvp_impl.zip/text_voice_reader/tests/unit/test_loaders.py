"""Tests for the loader layer."""

from __future__ import annotations

from pathlib import Path

import pytest

from text_voice_reader.loaders import (
    CsvLoader,
    HtmlLoader,
    LoaderError,
    LoaderFactory,
    MarkdownLoader,
    TxtLoader,
    UnsupportedFormatError,
    detect_encoding,
    read_text_auto,
)

FIXTURES = Path(__file__).parent.parent / "fixtures"


# -----------------------------------------------------------------------------
# Encoding detection
# -----------------------------------------------------------------------------


def test_detect_encoding_utf8():
    data = "こんにちは世界".encode("utf-8")
    result = detect_encoding(data)
    assert result.encoding == "utf-8"
    assert not result.had_bom


def test_detect_encoding_utf8_bom():
    data = "\ufeff" + "こんにちは"
    data_bytes = data.encode("utf-8")
    result = detect_encoding(data_bytes)
    assert result.encoding == "utf-8-sig"
    assert result.had_bom


def test_detect_encoding_cp932():
    # "テスト" in Shift_JIS / CP932
    data = "テストです".encode("cp932")
    result = detect_encoding(data)
    # CP932 and Shift_JIS are both acceptable
    assert result.encoding in {"cp932", "shift_jis"}


def test_read_text_auto_utf8(tmp_path):
    f = tmp_path / "u.txt"
    f.write_bytes("テスト".encode("utf-8"))
    assert read_text_auto(f) == "テスト"


def test_read_text_auto_cp932(tmp_path):
    f = tmp_path / "s.txt"
    f.write_bytes("テスト".encode("cp932"))
    assert read_text_auto(f) == "テスト"


# -----------------------------------------------------------------------------
# TxtLoader
# -----------------------------------------------------------------------------


def test_txt_loader_reads_fixture():
    loader = TxtLoader()
    text = loader.load(FIXTURES / "sample.txt")
    assert "TextVoiceReader" in text
    assert "こんにちは" in text


def test_txt_loader_missing_file():
    loader = TxtLoader()
    with pytest.raises(LoaderError):
        loader.load(Path("definitely/does/not/exist.txt"))


# -----------------------------------------------------------------------------
# MarkdownLoader
# -----------------------------------------------------------------------------


def test_markdown_loader_strips_code_blocks():
    loader = MarkdownLoader()
    text = loader.load(FIXTURES / "sample.md")
    assert "読み上げられない" not in text  # inside ``` fence
    assert "サンプル Markdown" in text
    assert "最終段落" in text


# -----------------------------------------------------------------------------
# HtmlLoader
# -----------------------------------------------------------------------------


def test_html_loader_strips_script_and_style():
    loader = HtmlLoader()
    text = loader.load(FIXTURES / "sample.html")
    assert "HTMLタイトル" in text
    assert "読み上げられない" not in text
    assert "color: red" not in text


# -----------------------------------------------------------------------------
# CsvLoader
# -----------------------------------------------------------------------------


def test_csv_loader_joins_rows():
    loader = CsvLoader()
    text = loader.load(FIXTURES / "sample.csv")
    assert "太郎" in text
    assert "エンジニア" in text
    # Rows should be joined by "、"
    assert "、" in text


# -----------------------------------------------------------------------------
# Factory
# -----------------------------------------------------------------------------


def test_factory_resolves_txt():
    factory = LoaderFactory()
    loader = factory.resolve(Path("foo.txt"))
    assert isinstance(loader, TxtLoader)


def test_factory_resolves_md():
    factory = LoaderFactory()
    loader = factory.resolve(Path("foo.md"))
    assert isinstance(loader, MarkdownLoader)


def test_factory_unknown_extension():
    factory = LoaderFactory()
    with pytest.raises(UnsupportedFormatError):
        factory.resolve(Path("foo.xyz"))


def test_factory_supported_extensions_includes_all():
    factory = LoaderFactory()
    exts = factory.supported_extensions()
    for e in {".txt", ".md", ".pdf", ".docx", ".pptx", ".html", ".csv", ".msg"}:
        assert e in exts
