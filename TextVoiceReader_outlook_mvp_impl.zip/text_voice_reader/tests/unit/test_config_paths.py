from __future__ import annotations

from text_voice_reader.config import load_config
from text_voice_reader.utils.paths import get_package_config_path, get_packaged_config_text


def test_packaged_default_config_is_available():
    path = get_package_config_path()
    assert path.is_file()
    assert path.name == "default.toml"


def test_load_config_reads_packaged_default_when_user_file_missing(tmp_path):
    cfg = load_config(user_config_path=tmp_path / "missing.toml")
    packaged = get_packaged_config_text()

    assert "[tts]" in packaged
    assert cfg.tts.engine == "sapi5"
    assert cfg.output.save_wav is True
