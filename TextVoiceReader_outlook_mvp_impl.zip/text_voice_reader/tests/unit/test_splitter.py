"""Tests for SentenceSplitter."""

from __future__ import annotations

from text_voice_reader.processing.splitter import SentenceSplitter, SplitterOptions


def test_split_simple_japanese():
    s = SentenceSplitter(SplitterOptions(max_chars=120))
    out = s.split("こんにちは。元気ですか？今日は良い天気です。")
    texts = [x.text for x in out]
    assert len(texts) == 3
    assert texts[0].startswith("こんにちは")
    assert texts[1].startswith("元気")


def test_split_simple_english():
    s = SentenceSplitter(SplitterOptions(max_chars=120))
    out = s.split("Hello. How are you? I am fine.")
    assert len(out) == 3


def test_split_assigns_ids_in_order():
    s = SentenceSplitter(SplitterOptions(max_chars=120))
    out = s.split("A。B。C。")
    assert [x.id for x in out] == [0, 1, 2]


def test_split_max_chars_soft_break():
    s = SentenceSplitter(SplitterOptions(max_chars=15))
    # Long single sentence forces soft-break on commas
    text = "あいうえお、かきくけこ、さしすせそ、たちつてと。"
    out = s.split(text)
    assert all(len(x.text) <= 20 for x in out)
    assert len(out) >= 2


def test_split_empty_input():
    s = SentenceSplitter(SplitterOptions())
    assert s.split("") == []


def test_split_very_long_no_punctuation():
    s = SentenceSplitter(SplitterOptions(max_chars=10))
    text = "a" * 35  # no punctuation at all
    out = s.split(text)
    assert len(out) >= 3
    # Hard-wrapped chunks should be at most max_chars each
    for x in out:
        assert len(x.text) <= 10


def test_split_preserves_terminators():
    s = SentenceSplitter(SplitterOptions(max_chars=120))
    out = s.split("これは文です。")
    assert out[0].text.endswith("。")


def test_merge_short_combines_tiny_fragments():
    s = SentenceSplitter(SplitterOptions(max_chars=60, merge_short_min=5))
    out = s.split("長い文章があります。短。さらに別の文章です。")
    # The very short "短。" should merge into an adjacent fragment
    for x in out:
        assert x.text != "短"


def test_split_keeps_common_english_abbreviations_together():
    s = SentenceSplitter(SplitterOptions(max_chars=120))
    out = s.split("Dr. Smith went home. He slept.")
    assert [x.text for x in out] == ["Dr. Smith went home.", "He slept."]
