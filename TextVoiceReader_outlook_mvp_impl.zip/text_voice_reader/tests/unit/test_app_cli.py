from __future__ import annotations

import argparse
from pathlib import Path

from text_voice_reader.app import _run_cli
from text_voice_reader.config import AppConfig
from text_voice_reader.orchestrator.app_orchestrator import RunResult


class _FakeOrchestrator:
    def __init__(self, cfg: AppConfig, result: RunResult):
        self._result = result

    def load_and_prepare(self, path: Path):
        return [type("Sentence", (), {"text": "hello"})()]

    def prepare_text(self, text: str):
        return [type("Sentence", (), {"text": text or "hello"})()]

    def run(self, *args, **kwargs):
        return self._result

    def get_engine(self):  # pragma: no cover
        raise NotImplementedError


def _args(tmp_path: Path, **overrides):
    data = {
        "list_voices": False,
        "file": None,
        "text": "hello",
        "out": None,
        "voice": None,
        "rate": None,
        "volume": None,
        "pitch": None,
        "no_gui": True,
        "no_play": False,
        "no_save": False,
    }
    data.update(overrides)
    return argparse.Namespace(**data)


def test_run_cli_returns_nonzero_on_partial_failure(monkeypatch, tmp_path: Path, capsys):
    result = RunResult(
        total_sentences=3,
        completed=2,
        failed=1,
        output_wav=None,
        cancelled=False,
    )
    monkeypatch.setattr(
        "text_voice_reader.app.AppOrchestrator",
        lambda cfg: _FakeOrchestrator(cfg, result),
    )

    code = _run_cli(_args(tmp_path), AppConfig())

    captured = capsys.readouterr()
    assert code == 1
    assert "success=2 failed=1 total=3" in captured.err


def test_run_cli_returns_zero_on_full_success(monkeypatch, tmp_path: Path):
    result = RunResult(
        total_sentences=1,
        completed=1,
        failed=0,
        output_wav=None,
        cancelled=False,
    )
    monkeypatch.setattr(
        "text_voice_reader.app.AppOrchestrator",
        lambda cfg: _FakeOrchestrator(cfg, result),
    )

    code = _run_cli(_args(tmp_path), AppConfig())

    assert code == 0
