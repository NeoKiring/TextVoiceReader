"""Tests for Sapi5Engine using a mocked win32com.client layer.

The engine imports win32com.client lazily inside ``_require_win32()``. We
patch that helper to return a MagicMock that mimics SAPI5's COM interface
closely enough to exercise the engine's public API.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock

import pytest


@pytest.fixture
def mock_w32(monkeypatch):
    """Replace ``_require_win32`` with one that returns a mock win32com module."""
    from text_voice_reader.tts import sapi5_engine as mod

    w32 = MagicMock(name="win32com.client")

    # Factory that returns a distinct mock per Dispatch call site
    voices_collection = MagicMock(name="SpVoices")
    voice_token = MagicMock()
    voice_token.Id = "HKEY_LOCAL_MACHINE\\...\\Haruka"
    voice_token.GetDescription.return_value = "Microsoft Haruka Desktop"
    voice_token.GetAttribute = MagicMock(side_effect=lambda k: {"Language": "411", "Gender": "Female"}.get(k, ""))
    voices_collection.Count = 1
    voices_collection.Item.return_value = voice_token

    speaker = MagicMock(name="SpVoice")
    speaker.GetVoices.return_value = voices_collection
    speaker.AudioOutputStream = MagicMock()

    file_stream = MagicMock(name="SpFileStream")
    audio_format = MagicMock(name="SpAudioFormat")

    def _dispatch(name: str):
        if name == "SAPI.SpVoice":
            return speaker
        if name == "SAPI.SpFileStream":
            return file_stream
        if name == "SAPI.SpAudioFormat":
            return audio_format
        raise AssertionError(f"Unexpected Dispatch({name!r})")

    w32.Dispatch.side_effect = _dispatch

    pythoncom = MagicMock(name="pythoncom")
    monkeypatch.setattr(mod, "_require_win32", lambda: w32)
    monkeypatch.setattr(mod, "_require_pythoncom", lambda: pythoncom)
    return {
        "w32": w32,
        "speaker": speaker,
        "voices": voices_collection,
        "voice_token": voice_token,
        "file_stream": file_stream,
        "audio_format": audio_format,
        "pythoncom": pythoncom,
    }


def test_list_voices_returns_info(mock_w32):
    from text_voice_reader.tts.sapi5_engine import Sapi5Engine

    engine = Sapi5Engine()
    voices = engine.list_voices()

    assert len(voices) == 1
    assert voices[0].name == "Microsoft Haruka Desktop"
    assert voices[0].engine == "sapi5"
    assert voices[0].gender == "female"


def test_list_voices_is_cached(mock_w32):
    from text_voice_reader.tts.sapi5_engine import Sapi5Engine

    engine = Sapi5Engine()
    engine.list_voices()
    engine.list_voices()
    # The speaker.GetVoices is called twice: once during __init__ selection? No.
    # It should only be called on list_voices, and second call hits cache.
    # Count calls since the fixture created fresh mocks:
    assert mock_w32["speaker"].GetVoices.call_count <= 2  # selection may also call


def test_synthesize_to_file_opens_stream(mock_w32, tmp_path: Path):
    from text_voice_reader.tts.sapi5_engine import Sapi5Engine
    from text_voice_reader.tts.options import SynthesisOptions

    engine = Sapi5Engine()
    out = tmp_path / "out.wav"
    opts = SynthesisOptions(rate=2, volume=80)
    engine.synthesize_to_file("hello", out, opts)

    assert mock_w32["file_stream"].Open.called
    args, _ = mock_w32["file_stream"].Open.call_args
    assert args[0] == str(out)
    # SSFM_CREATE_FOR_WRITE = 3
    assert args[1] == 3
    assert mock_w32["speaker"].Speak.called


def test_synthesize_rejects_empty_text(mock_w32, tmp_path: Path):
    from text_voice_reader.tts.sapi5_engine import Sapi5Engine
    from text_voice_reader.tts.base import TtsError
    from text_voice_reader.tts.options import SynthesisOptions

    engine = Sapi5Engine()
    with pytest.raises(TtsError):
        engine.synthesize_to_file("", tmp_path / "x.wav", SynthesisOptions())


def test_speak_async_returns_handle(mock_w32):
    from text_voice_reader.tts.sapi5_engine import Sapi5Engine
    from text_voice_reader.tts.options import SynthesisOptions

    engine = Sapi5Engine()
    handle = engine.speak_async("テスト", SynthesisOptions(rate=0, volume=90))
    assert handle is not None
    # SVSF_ASYNC = 1 in flags
    args, _ = mock_w32["speaker"].Speak.call_args
    assert args[0] == "テスト"
    assert args[1] & 1  # SVSF_ASYNC


def test_speak_async_with_pitch_uses_ssml(mock_w32):
    from text_voice_reader.tts.sapi5_engine import Sapi5Engine
    from text_voice_reader.tts.options import SynthesisOptions

    engine = Sapi5Engine()
    engine.speak_async("テスト", SynthesisOptions(pitch=5, use_ssml=True))
    args, _ = mock_w32["speaker"].Speak.call_args
    # SVSF_IS_XML = 8
    assert args[1] & 8
    assert "<speak" in args[0]


def test_handle_stop_calls_purge(mock_w32):
    from text_voice_reader.tts.sapi5_engine import Sapi5Engine
    from text_voice_reader.tts.options import SynthesisOptions

    engine = Sapi5Engine()
    handle = engine.speak_async("テスト", SynthesisOptions())
    handle.stop()
    # Final Speak call should have been with empty string + purge flag
    last_call = mock_w32["speaker"].Speak.call_args
    assert last_call.args[0] == ""
    # SVSF_ASYNC | SVSF_PURGE_BEFORE_SPEAK = 1 | 2 = 3
    assert last_call.args[1] & 2
