from __future__ import annotations

from text_voice_reader.integrations.outlook.models import OutlookMailSnapshot
from text_voice_reader.integrations.outlook.monitor import OutlookMailMonitor


def _mail(entry_id: str) -> OutlookMailSnapshot:
    return OutlookMailSnapshot(
        entry_id=entry_id,
        subject="subject",
        sender_name="sender",
        sender_email=None,
        received_at=None,
        body_preview="preview",
        full_body="full",
        unread=True,
    )


class _FakeClient:
    def __init__(self) -> None:
        self.calls = 0

    def list_recent_messages(self, **kwargs):
        self.calls += 1
        if self.calls == 1:
            return [_mail("1"), _mail("2")]
        return [_mail("1"), _mail("2"), _mail("3")]


def test_monitor_check_once_filters_duplicates_and_returns_oldest_first():
    client = _FakeClient()
    seen = []
    monitor = OutlookMailMonitor(client, on_mail=seen.append, max_queue_size=10)

    first = monitor.check_once()
    second = monitor.check_once()

    assert [m.entry_id for m in first] == ["2", "1"]
    assert [m.entry_id for m in second] == ["3"]
