from __future__ import annotations

import runpy

import pytest


def test_python_m_entrypoint_propagates_exit_code(monkeypatch):
    monkeypatch.setattr("text_voice_reader.app.main", lambda: 7)

    with pytest.raises(SystemExit) as exc_info:
        runpy.run_module("text_voice_reader.__main__", run_name="__main__")

    assert exc_info.value.code == 7
