from __future__ import annotations

from pathlib import Path

from text_voice_reader.config import AppConfig, OutputSection, ProcessingSection, TtsSection
from text_voice_reader.orchestrator.app_orchestrator import AppOrchestrator
from text_voice_reader.processing.splitter import Sentence
from text_voice_reader.tts.options import SynthesisOptions
from text_voice_reader.utils.threading_utils import StopToken


class _FakeEngine:
    name = "fake"

    def list_voices(self):
        return []

    def synthesize_to_file(self, text: str, wav_path: Path, opts: SynthesisOptions) -> None:
        wav_path.write_bytes(f"WAV:{text}".encode("utf-8"))

    def speak_async(self, text: str, opts: SynthesisOptions):  # pragma: no cover
        raise NotImplementedError


def _make_cfg(tmp_path: Path) -> AppConfig:
    return AppConfig(
        tts=TtsSection(engine="onnx"),
        output=OutputSection(
            play=False,
            save_wav=True,
            save_dir=str(tmp_path),
            wav_sample_rate=22050,
        ),
        processing=ProcessingSection(),
    )


def test_run_result_counts_partial_failures(monkeypatch, tmp_path: Path):
    orch = AppOrchestrator(_make_cfg(tmp_path))
    monkeypatch.setattr(orch, "get_engine", lambda: _FakeEngine())

    sentences = [Sentence(id=0, text="ok"), Sentence(id=1, text="boom")]

    calls: list[str] = []

    class _FakeHybridSink:
        def __init__(self, *args, **kwargs):
            self._save_path = kwargs.get("save_path")

        def __enter__(self):
            return self

        def __exit__(self, *exc_info):
            return None

        def consume(self, text: str, opts: SynthesisOptions, stop: StopToken) -> None:
            calls.append(text)
            if text == "boom":
                raise RuntimeError("synthetic failure")

    monkeypatch.setattr(
        "text_voice_reader.orchestrator.app_orchestrator.HybridSink",
        _FakeHybridSink,
    )

    result = orch.run(sentences, play=False, save_wav=True, source_name="sample")

    assert calls == ["ok", "boom"]
    assert result.completed == 1
    assert result.failed == 1
    assert result.total_sentences == 2
    assert result.cancelled is False


def test_run_result_preserves_failure_count_on_cancel(monkeypatch, tmp_path: Path):
    orch = AppOrchestrator(_make_cfg(tmp_path))
    monkeypatch.setattr(orch, "get_engine", lambda: _FakeEngine())

    sentences = [Sentence(id=0, text="ok"), Sentence(id=1, text="later")]
    stop = StopToken()

    class _FakeHybridSink:
        def __init__(self, *args, **kwargs):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *exc_info):
            return None

        def consume(self, text: str, opts: SynthesisOptions, stop_token: StopToken) -> None:
            stop.set()

    monkeypatch.setattr(
        "text_voice_reader.orchestrator.app_orchestrator.HybridSink",
        _FakeHybridSink,
    )

    result = orch.run(sentences, play=False, save_wav=True, source_name="sample", stop=stop)

    assert result.completed == 1
    assert result.failed == 0
    assert result.cancelled is True
