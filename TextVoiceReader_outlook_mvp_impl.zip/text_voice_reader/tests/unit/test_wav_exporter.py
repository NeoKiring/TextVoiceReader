"""Tests for WavExporter."""

from __future__ import annotations

import wave
from pathlib import Path

import pytest

from text_voice_reader.audio.wav_exporter import AudioError, WavExporter


def _write_wav(path: Path, *, rate: int = 22050, channels: int = 1, sampwidth: int = 2,
               duration_seconds: float = 0.1) -> None:
    n_frames = int(rate * duration_seconds)
    silence = b"\x00" * (n_frames * channels * sampwidth)
    with wave.open(str(path), "wb") as w:
        w.setnchannels(channels)
        w.setsampwidth(sampwidth)
        w.setframerate(rate)
        w.writeframes(silence)


def test_exporter_creates_file_on_first_append(tmp_path: Path):
    src = tmp_path / "src.wav"
    _write_wav(src)
    out = tmp_path / "dst.wav"

    with WavExporter(out) as exp:
        exp.append(src)

    assert out.is_file()
    with wave.open(str(out), "rb") as r:
        assert r.getframerate() == 22050
        assert r.getnchannels() == 1


def test_exporter_concatenates_multiple(tmp_path: Path):
    a = tmp_path / "a.wav"
    b = tmp_path / "b.wav"
    _write_wav(a, duration_seconds=0.1)
    _write_wav(b, duration_seconds=0.2)
    out = tmp_path / "combined.wav"

    with WavExporter(out) as exp:
        exp.append(a)
        exp.append(b)

    with wave.open(str(out), "rb") as r:
        frames = r.getnframes()
        rate = r.getframerate()
    total_seconds = frames / rate
    assert 0.29 < total_seconds < 0.31


def test_exporter_rejects_format_mismatch(tmp_path: Path):
    a = tmp_path / "a.wav"
    b = tmp_path / "b.wav"
    _write_wav(a, rate=22050)
    _write_wav(b, rate=44100)
    out = tmp_path / "c.wav"

    with pytest.raises(AudioError):
        with WavExporter(out) as exp:
            exp.append(a)
            exp.append(b)


def test_exporter_missing_file(tmp_path: Path):
    out = tmp_path / "out.wav"
    with pytest.raises(AudioError):
        with WavExporter(out) as exp:
            exp.append(tmp_path / "nope.wav")


def test_exporter_close_is_idempotent(tmp_path: Path):
    src = tmp_path / "a.wav"
    _write_wav(src)
    out = tmp_path / "out.wav"
    exp = WavExporter(out)
    exp.append(src)
    exp.close()
    exp.close()  # should not raise
