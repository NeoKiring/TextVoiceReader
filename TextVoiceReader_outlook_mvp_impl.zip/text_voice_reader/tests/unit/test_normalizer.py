"""Tests for TextNormalizer."""

from __future__ import annotations

from text_voice_reader.processing.normalizer import NormalizerOptions, TextNormalizer


def test_normalizer_nfkc_converts_fullwidth():
    n = TextNormalizer(NormalizerOptions(nfkc=True))
    assert n.normalize("ABC123") == "ABC123"


def test_normalizer_strips_control_characters():
    n = TextNormalizer(NormalizerOptions())
    result = n.normalize("hello\x00world\x07")
    assert "\x00" not in result
    assert "\x07" not in result
    assert "hello" in result and "world" in result


def test_normalizer_collapses_whitespace():
    n = TextNormalizer(NormalizerOptions())
    result = n.normalize("a     b\t\tc")
    assert result == "a b c"


def test_normalizer_strips_urls():
    n = TextNormalizer(NormalizerOptions(strip_urls=True, url_replacement=""))
    result = n.normalize("see https://example.com now")
    assert "example.com" not in result


def test_normalizer_keeps_urls_if_disabled():
    n = TextNormalizer(NormalizerOptions(strip_urls=False))
    result = n.normalize("see https://example.com")
    assert "example.com" in result


def test_normalizer_strips_emojis():
    n = TextNormalizer(NormalizerOptions(strip_emojis=True))
    result = n.normalize("hello 😀 world")
    assert "😀" not in result


def test_normalizer_skip_empty_lines():
    n = TextNormalizer(NormalizerOptions(skip_empty_lines=True))
    result = n.normalize("a\n\n\nb\n   \nc")
    assert result.splitlines() == ["a", "b", "c"]


def test_normalizer_idempotent():
    n = TextNormalizer(NormalizerOptions())
    once = n.normalize("  hello   world  ")
    twice = n.normalize(once)
    assert once == twice


def test_normalizer_empty_input():
    n = TextNormalizer(NormalizerOptions())
    assert n.normalize("") == ""
