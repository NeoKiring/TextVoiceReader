from __future__ import annotations

from text_voice_reader.ui.ui_bridge import UiBridge


class _FakeRoot:
    def __init__(self) -> None:
        self.calls: list[tuple[int, object]] = []
        self.cancelled: list[object] = []
        self.next_id = 0

    def after(self, delay_ms: int, callback):
        token = f"after-{self.next_id}"
        self.next_id += 1
        self.calls.append((delay_ms, callback))
        return token

    def after_cancel(self, after_id):
        self.cancelled.append(after_id)


def test_post_is_ignored_after_shutdown():
    root = _FakeRoot()
    bridge = UiBridge(root, poll_ms=1)

    called: list[str] = []
    bridge.shutdown()
    bridge.post(called.append, "late")

    assert called == []


def test_shutdown_cancels_pending_after_callback():
    root = _FakeRoot()
    bridge = UiBridge(root, poll_ms=1)

    assert root.cancelled == []
    bridge.shutdown()

    assert root.cancelled == ["after-0"]
