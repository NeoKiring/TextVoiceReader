from __future__ import annotations

from text_voice_reader.integrations.outlook.formatter import (
    MailSpeechFormatOptions,
    MailSpeechFormatter,
)
from text_voice_reader.integrations.outlook.models import OutlookMailSnapshot
from text_voice_reader.integrations.outlook.sanitizer import MailBodySanitizer


def test_sanitizer_preview_strips_html_url_and_limits_text():
    sanitizer = MailBodySanitizer()
    text = "<p>こんにちは https://example.com/path</p><p>明日の会議です。</p>"

    assert sanitizer.preview(text, max_chars=12) == "こんにちは URL省略…"


def test_sanitizer_full_body_can_be_unlimited():
    sanitizer = MailBodySanitizer()
    body = "A" * 500

    assert sanitizer.full_body(body, max_chars=0) == body


def test_formatter_preview_and_full_body():
    mail = OutlookMailSnapshot(
        entry_id="id-1",
        subject="会議変更",
        sender_name="山田太郎",
        sender_email="taro@example.com",
        received_at=None,
        body_preview="午後三時に変更します。",
        full_body="午後三時に変更します。資料を確認してください。",
        unread=True,
    )
    formatter = MailSpeechFormatter(
        MailSpeechFormatOptions(
            include_sender=True,
            include_subject=True,
            include_body_preview=True,
        )
    )

    preview = formatter.format_preview(mail)
    assert "新着メールです" in preview
    assert "差出人は、山田太郎さん" in preview
    assert "件名は、会議変更" in preview
    assert "本文の冒頭は、午後三時" in preview

    full = formatter.format_full_body(mail)
    assert "メール本文を読み上げます" in full
    assert "資料を確認してください" in full
