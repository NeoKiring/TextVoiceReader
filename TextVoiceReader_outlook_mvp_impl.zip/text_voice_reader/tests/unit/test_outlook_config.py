from __future__ import annotations

from text_voice_reader.config import AppConfig, load_config


def test_outlook_defaults_are_disabled():
    cfg = AppConfig()
    assert cfg.outlook.enabled is False
    assert cfg.outlook.mode == "polling"
    assert cfg.outlook.ask_before_full_body is True
    assert cfg.outlook.body_preview_max_chars == 300


def test_packaged_config_contains_outlook_defaults(tmp_path):
    cfg = load_config(user_config_path=tmp_path / "missing.toml")
    assert cfg.outlook.enabled is False
    assert cfg.outlook.unread_only is True
    assert cfg.outlook.poll_interval_seconds == 15
