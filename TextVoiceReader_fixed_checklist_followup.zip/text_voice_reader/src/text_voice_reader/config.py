"""Configuration models and loader for TextVoiceReader.

The configuration uses a layered approach:

1. Defaults baked into the pydantic models.
2. ``default.toml`` shipped inside the package.
3. User override at ``%APPDATA%/TextVoiceReader/config.toml`` (Windows) or
   ``~/.config/TextVoiceReader/config.toml`` (Linux/macOS for dev).
4. Environment variables prefixed with ``TVR_``.

Call :func:`load_config` to obtain a fully merged :class:`AppConfig`.

Example:
    >>> from text_voice_reader.config import load_config
    >>> cfg = load_config()
    >>> cfg.tts.voice
    ''
"""

from __future__ import annotations

import tomllib
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from text_voice_reader.utils.paths import (
    get_packaged_config_text,
    get_user_config_path,
    resolve_user_path,
)


class AppSection(BaseModel):
    """General application settings."""

    theme: Literal["dark", "light", "system"] = "dark"
    ui_language: Literal["ja", "en"] = "ja"


class TtsSection(BaseModel):
    """TTS engine settings."""

    engine: Literal["sapi5", "onnx"] = "sapi5"
    voice: str = ""
    rate: int = Field(default=0, ge=-10, le=10)
    volume: int = Field(default=90, ge=0, le=100)
    pitch: int = Field(default=0, ge=-10, le=10)
    use_ssml: bool = True
    onnx_model_path: str = ""


class OutputSection(BaseModel):
    """Audio output settings."""

    play: bool = True
    save_wav: bool = True
    save_dir: str = "~/Documents/TextVoiceReader/out"
    wav_sample_rate: Literal[22050, 44100] = 22050
    temp_dir: str = ""

    @field_validator("save_dir", "temp_dir")
    @classmethod
    def _keep_as_str(cls, v: str) -> str:
        return v


class ProcessingSection(BaseModel):
    """Text pre-processing settings."""

    normalize_nfkc: bool = True
    strip_urls: bool = True
    split_max_chars: int = Field(default=120, ge=20, le=1000)
    skip_empty_lines: bool = True
    pdf_strip_headers: bool = True


class LoggingSection(BaseModel):
    """Logging settings."""

    level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = "INFO"
    log_to_file: bool = True
    rotation: str = "10 MB"
    retention: str = "14 days"


class AppConfig(BaseSettings):
    """Top-level application config.

    Supports env var overrides with prefix ``TVR_`` and double-underscore
    section delimiter, e.g. ``TVR_TTS__VOICE=Haruka``.
    """

    model_config = SettingsConfigDict(
        env_prefix="TVR_",
        env_nested_delimiter="__",
        extra="ignore",
    )

    app: AppSection = Field(default_factory=AppSection)
    tts: TtsSection = Field(default_factory=TtsSection)
    output: OutputSection = Field(default_factory=OutputSection)
    processing: ProcessingSection = Field(default_factory=ProcessingSection)
    logging: LoggingSection = Field(default_factory=LoggingSection)

    def resolved_save_dir(self) -> Path:
        """Return the save directory with ~ and env vars expanded."""
        return resolve_user_path(self.output.save_dir)

    def resolved_temp_dir(self) -> Path | None:
        """Return the temp directory or None to use system temp."""
        if not self.output.temp_dir:
            return None
        return resolve_user_path(self.output.temp_dir)


def _read_toml(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {}
    with path.open("rb") as f:
        return tomllib.load(f)


def _read_packaged_default() -> dict[str, Any]:
    return tomllib.loads(get_packaged_config_text())


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    """Recursive dict merge. Values in ``override`` win."""
    out = dict(base)
    for k, v in override.items():
        if k in out and isinstance(out[k], dict) and isinstance(v, dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def load_config(user_config_path: Path | None = None) -> AppConfig:
    """Load config from package default + user override + environment.

    Args:
        user_config_path: Optional override for user config file location.

    Returns:
        Fully merged :class:`AppConfig`.
    """
    package_default = _read_packaged_default()
    user_path = user_config_path or get_user_config_path()
    user_data = _read_toml(user_path)
    merged = _deep_merge(package_default, user_data)
    # BaseSettings handles env vars automatically
    return AppConfig(**merged)


def save_user_config(cfg: AppConfig, path: Path | None = None) -> Path:
    """Serialize cfg to TOML at user config location.

    Args:
        cfg: Config to save.
        path: Optional custom path. Defaults to standard user config path.

    Returns:
        The path written to.
    """
    import toml  # lazy; only needed on save

    target = path or get_user_config_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    data = cfg.model_dump()
    with target.open("w", encoding="utf-8") as f:
        toml.dump(data, f)
    return target


__all__ = [
    "AppConfig",
    "AppSection",
    "TtsSection",
    "OutputSection",
    "ProcessingSection",
    "LoggingSection",
    "load_config",
    "save_user_config",
]
