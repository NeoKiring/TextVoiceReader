"""Settings panel: voice selection, speed/volume/pitch, output options."""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path
from tkinter import filedialog

import customtkinter as ctk

from text_voice_reader.config import AppConfig
from text_voice_reader.tts.options import VoiceInfo


class SettingsPanel(ctk.CTkFrame):
    """Right-hand panel with TTS parameters and output directory picker."""

    def __init__(
        self,
        master: ctk.CTkBaseClass,
        cfg: AppConfig,
        *,
        on_voice_load: Callable[[], list[VoiceInfo]] | None = None,
        **kwargs,
    ) -> None:
        super().__init__(master, **kwargs)
        self._cfg = cfg
        self._on_voice_load = on_voice_load
        self._voices: list[VoiceInfo] = []

        self._build_ui()

    # -----------------------------------------------------------------
    # Public getters
    # -----------------------------------------------------------------

    @property
    def selected_voice(self) -> str:
        return self._voice_var.get() if self._voice_var else ""

    @property
    def rate(self) -> int:
        return int(self._rate_var.get())

    @property
    def volume(self) -> int:
        return int(self._volume_var.get())

    @property
    def pitch(self) -> int:
        return int(self._pitch_var.get())

    @property
    def play_enabled(self) -> bool:
        return bool(self._play_var.get())

    @property
    def save_enabled(self) -> bool:
        return bool(self._save_var.get())

    @property
    def save_dir(self) -> Path:
        return Path(self._savedir_var.get()).expanduser()

    # -----------------------------------------------------------------
    # UI construction
    # -----------------------------------------------------------------

    def _build_ui(self) -> None:
        pad = {"padx": 8, "pady": 4}

        ctk.CTkLabel(self, text="🔊 音声設定", anchor="w", font=("Yu Gothic UI", 14, "bold")).pack(
            fill="x", padx=8, pady=(8, 4)
        )

        # Voice selector
        ctk.CTkLabel(self, text="Voice:").pack(fill="x", **pad)
        self._voice_var = ctk.StringVar(value=self._cfg.tts.voice)
        self._voice_menu = ctk.CTkOptionMenu(
            self, variable=self._voice_var, values=[self._cfg.tts.voice or "(default)"]
        )
        self._voice_menu.pack(fill="x", **pad)
        ctk.CTkButton(self, text="音声一覧を更新", command=self._reload_voices).pack(
            fill="x", **pad
        )

        # Rate
        ctk.CTkLabel(self, text="Speed  (-10 … +10)").pack(fill="x", **pad)
        self._rate_var = ctk.IntVar(value=self._cfg.tts.rate)
        self._rate_slider = ctk.CTkSlider(
            self, from_=-10, to=10, number_of_steps=20, variable=self._rate_var
        )
        self._rate_slider.pack(fill="x", **pad)

        # Volume
        ctk.CTkLabel(self, text="Volume  (0 … 100)").pack(fill="x", **pad)
        self._volume_var = ctk.IntVar(value=self._cfg.tts.volume)
        self._volume_slider = ctk.CTkSlider(
            self, from_=0, to=100, number_of_steps=100, variable=self._volume_var
        )
        self._volume_slider.pack(fill="x", **pad)

        # Pitch
        ctk.CTkLabel(self, text="Pitch  (-10 … +10)").pack(fill="x", **pad)
        self._pitch_var = ctk.IntVar(value=self._cfg.tts.pitch)
        self._pitch_slider = ctk.CTkSlider(
            self, from_=-10, to=10, number_of_steps=20, variable=self._pitch_var
        )
        self._pitch_slider.pack(fill="x", **pad)

        # Output section
        ctk.CTkLabel(
            self, text="📁 出力", anchor="w", font=("Yu Gothic UI", 14, "bold")
        ).pack(fill="x", padx=8, pady=(16, 4))

        self._play_var = ctk.BooleanVar(value=self._cfg.output.play)
        ctk.CTkCheckBox(self, text="再生", variable=self._play_var).pack(fill="x", **pad)

        self._save_var = ctk.BooleanVar(value=self._cfg.output.save_wav)
        ctk.CTkCheckBox(self, text="WAV 保存", variable=self._save_var).pack(fill="x", **pad)

        ctk.CTkLabel(self, text="保存先:").pack(fill="x", **pad)
        self._savedir_var = ctk.StringVar(value=str(self._cfg.resolved_save_dir()))
        savedir_frame = ctk.CTkFrame(self, fg_color="transparent")
        savedir_frame.pack(fill="x", **pad)
        ctk.CTkEntry(savedir_frame, textvariable=self._savedir_var).pack(
            side="left", fill="x", expand=True
        )
        ctk.CTkButton(
            savedir_frame, text="選択", width=60, command=self._pick_save_dir
        ).pack(side="right", padx=(4, 0))

    # -----------------------------------------------------------------
    # Actions
    # -----------------------------------------------------------------

    def _reload_voices(self) -> None:
        if self._on_voice_load is None:
            return
        try:
            self._voices = self._on_voice_load()
        except Exception as e:
            self._voice_menu.configure(values=[f"(error: {e})"])
            return
        labels = [v.name for v in self._voices] or ["(no voices found)"]
        self._voice_menu.configure(values=labels)
        current = self._voice_var.get()
        if current not in labels:
            self._voice_var.set(labels[0])

    def _pick_save_dir(self) -> None:
        chosen = filedialog.askdirectory(
            initialdir=self._savedir_var.get() or str(Path.home())
        )
        if chosen:
            self._savedir_var.set(chosen)


__all__ = ["SettingsPanel"]
