"""Main application window.

Layout
======

+---------------------------------------------------------------+
| Toolbar: 📂 ファイル / 📋 クリップボード / 🗑 クリア           |
+----------------------------+----------------------------------+
|                            |                                  |
|   Preview (editable)       |   Settings (voice / output)      |
|                            |                                  |
+----------------------------+----------------------------------+
| Control bar: ▶ ⏹    progress bar                              |
+---------------------------------------------------------------+
| ▸ Log (collapsible)                                           |
+---------------------------------------------------------------+
"""

from __future__ import annotations

from pathlib import Path
from tkinter import filedialog, messagebox

import customtkinter as ctk
import pyperclip

from text_voice_reader import __version__
from text_voice_reader.config import AppConfig
from text_voice_reader.logging_setup import get_logger
from text_voice_reader.orchestrator import AppOrchestrator, RunResult
from text_voice_reader.processing.splitter import Sentence
from text_voice_reader.ui.control_panel import ControlPanel
from text_voice_reader.ui.log_panel import LogPanel
from text_voice_reader.ui.preview_panel import PreviewPanel
from text_voice_reader.ui.settings_panel import SettingsPanel
from text_voice_reader.ui.ui_bridge import UiBridge
from text_voice_reader.utils.threading_utils import StopToken, run_in_thread

_log = get_logger(__name__)


class MainWindow(ctk.CTk):
    """Top-level window."""

    def __init__(self, cfg: AppConfig) -> None:
        super().__init__()
        self._cfg = cfg
        self._orch = AppOrchestrator(cfg)
        self._current_sentences: list[Sentence] = []
        self._current_source = "input"
        self._stop_token: StopToken | None = None
        self._worker_thread = None
        self._closing = False
        self._close_deadline_ms = 2000

        # Window configuration
        ctk.set_appearance_mode(cfg.app.theme)
        ctk.set_default_color_theme("blue")
        self.title(f"TextVoiceReader {__version__}")
        self.geometry("1100x720")
        self.minsize(900, 600)

        self._bridge = UiBridge(self)

        self._build_layout()
        self._bind_close()

        # Populate voices once on startup (non-blocking failure is fine)
        try:
            voices = self._orch.get_engine().list_voices()
            labels = [v.name for v in voices]
            if labels:
                self._settings._voice_menu.configure(values=labels)  # type: ignore[attr-defined]
                current = self._settings.selected_voice
                if current not in labels:
                    self._settings._voice_var.set(labels[0])  # type: ignore[attr-defined]
        except Exception as e:
            _log.warning(f"Voice enumeration failed at startup: {e}")

    # -----------------------------------------------------------------
    # Layout
    # -----------------------------------------------------------------

    def _build_layout(self) -> None:
        # Top toolbar
        toolbar = ctk.CTkFrame(self, height=48)
        toolbar.pack(fill="x", padx=8, pady=(8, 0))
        ctk.CTkButton(
            toolbar, text="📂 ファイルを開く", command=self._action_open_file
        ).pack(side="left", padx=4, pady=4)
        ctk.CTkButton(
            toolbar, text="📋 クリップボード", command=self._action_paste_clipboard
        ).pack(side="left", padx=4, pady=4)
        ctk.CTkButton(toolbar, text="🗑 クリア", command=self._action_clear).pack(
            side="left", padx=4, pady=4
        )
        ctk.CTkButton(
            toolbar, text="⚙ 設定を保存", command=self._action_save_config
        ).pack(side="right", padx=4, pady=4)

        # Central split: preview (left) + settings (right)
        central = ctk.CTkFrame(self, fg_color="transparent")
        central.pack(fill="both", expand=True, padx=8, pady=8)
        central.grid_columnconfigure(0, weight=3)
        central.grid_columnconfigure(1, weight=1, minsize=300)
        central.grid_rowconfigure(0, weight=1)

        self._preview = PreviewPanel(central)
        self._preview.grid(row=0, column=0, sticky="nsew", padx=(0, 6))

        self._settings = SettingsPanel(
            central,
            self._cfg,
            on_voice_load=lambda: self._orch.get_engine().list_voices(),
        )
        self._settings.grid(row=0, column=1, sticky="nsew")

        # Bottom control bar
        self._control = ControlPanel(
            self,
            on_play=self._action_play,
            on_stop=self._action_stop,
        )
        self._control.pack(fill="x", padx=8, pady=(0, 6))

        # Log panel
        self._log_panel = LogPanel(self, bridge=self._bridge)
        self._log_panel.pack(fill="x", padx=8, pady=(0, 8))

    def _bind_close(self) -> None:
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    def _on_close(self) -> None:
        if self._closing:
            return
        self._closing = True
        if self._stop_token is not None:
            self._stop_token.set()
        self._control.set_running(False)
        self.after(0, lambda: self._finalize_close(wait_ms=self._close_deadline_ms))

    def _finalize_close(self, wait_ms: int) -> None:
        worker = self._worker_thread
        if worker is not None and worker.is_alive() and wait_ms > 0:
            self.after(50, lambda: self._finalize_close(wait_ms - 50))
            return
        self._bridge.shutdown()
        self.destroy()

    # -----------------------------------------------------------------
    # Actions
    # -----------------------------------------------------------------

    def _action_open_file(self) -> None:
        supported = sorted(self._orch.supported_extensions())
        filetypes = [("対応ファイル", " ".join(f"*{e}" for e in supported)), ("すべて", "*.*")]
        path_str = filedialog.askopenfilename(filetypes=filetypes)
        if not path_str:
            return
        path = Path(path_str)
        try:
            sentences = self._orch.load_and_prepare(path)
        except Exception as e:
            messagebox.showerror("読み込み失敗", f"{path.name}:\n{e}")
            _log.exception(f"load failed: {e}")
            return
        self._current_sentences = sentences
        self._current_source = path.stem
        self._preview.set_sentences(sentences)
        self._control.set_progress(0, len(sentences))
        _log.info(f"Loaded {path.name}: {len(sentences)} sentences")

    def _action_paste_clipboard(self) -> None:
        try:
            text = pyperclip.paste() or ""
        except Exception as e:
            messagebox.showerror("クリップボード取得失敗", str(e))
            return
        if not text.strip():
            messagebox.showinfo("クリップボード", "空のテキストです")
            return
        try:
            sentences = self._orch.prepare_text(text)
        except Exception as e:
            messagebox.showerror("処理失敗", str(e))
            return
        self._current_sentences = sentences
        self._current_source = "clipboard"
        self._preview.set_sentences(sentences)
        self._control.set_progress(0, len(sentences))
        _log.info(f"Pasted clipboard: {len(sentences)} sentences")

    def _action_clear(self) -> None:
        self._current_sentences = []
        self._preview.set_text("")
        self._preview.clear_highlight()
        self._control.reset_progress()

    def _action_save_config(self) -> None:
        from text_voice_reader.config import save_user_config

        # Capture current UI values back into the config model
        data = self._cfg.model_dump()
        data["tts"]["voice"] = self._settings.selected_voice
        data["tts"]["rate"] = self._settings.rate
        data["tts"]["volume"] = self._settings.volume
        data["tts"]["pitch"] = self._settings.pitch
        data["output"]["play"] = self._settings.play_enabled
        data["output"]["save_wav"] = self._settings.save_enabled
        data["output"]["save_dir"] = str(self._settings.save_dir)
        self._cfg = AppConfig(**data)
        try:
            path = save_user_config(self._cfg)
            messagebox.showinfo("設定保存", f"保存しました:\n{path}")
        except Exception as e:
            messagebox.showerror("保存失敗", str(e))

    def _action_play(self) -> None:
        if self._closing:
            return
        if self._worker_thread is not None and self._worker_thread.is_alive():
            _log.warning("Play requested while a run is already active")
            return

        # Re-parse the (possibly edited) preview text
        text = self._preview.get_text()
        if not text.strip():
            messagebox.showinfo("テキストなし", "読み上げるテキストがありません")
            return
        sentences = self._orch.prepare_text(text)
        if not sentences:
            return

        self._current_sentences = sentences
        self._preview.set_sentences(sentences)

        # Reflect current settings back into the runtime config for this run
        runtime_cfg = self._make_runtime_config()
        self._orch = AppOrchestrator(runtime_cfg)
        self._current_source = self._current_source or "input"

        self._stop_token = StopToken()
        self._control.set_running(True)
        self._control.set_progress(0, len(sentences))

        self._worker_thread = run_in_thread(
            self._worker_run,
            sentences,
            runtime_cfg.output.play,
            runtime_cfg.output.save_wav,
            self._stop_token,
            name="tvr-run-worker",
        )

    def _action_stop(self) -> None:
        if self._stop_token is not None:
            self._stop_token.set()
            _log.info("Stop requested")

    # -----------------------------------------------------------------
    # Worker
    # -----------------------------------------------------------------

    def _worker_run(
        self,
        sentences: list[Sentence],
        play: bool,
        save_wav: bool,
        stop: StopToken,
    ) -> None:
        def _on_progress(cur: int, total: int, sentence: Sentence) -> None:
            if self._closing:
                return
            self._bridge.post(self._preview.highlight, sentence.id)
            self._bridge.post(
                self._control.set_progress, cur, total, sentence.text[:20]
            )

        try:
            result = self._orch.run(
                sentences,
                play=play,
                save_wav=save_wav,
                source_name=self._current_source,
                stop=stop,
                progress=_on_progress,
            )
            if not self._closing:
                self._bridge.post(self._on_run_complete, result)
        except Exception as e:
            _log.exception(f"Run failed: {e}")
            if not self._closing:
                self._bridge.post(
                    messagebox.showerror, "実行エラー", str(e)
                )
                self._bridge.post(self._control.set_running, False)

    def _on_run_complete(self, result: RunResult) -> None:
        if self._closing:
            return

        self._control.set_running(False)
        self._preview.clear_highlight()
        self._stop_token = None
        self._worker_thread = None

        if result.cancelled:
            self._control.reset_progress()
            _log.info("Run cancelled")
            return

        summary = (
            f"Run complete: success={result.completed}, failed={result.failed}, "
            f"total={result.total_sentences}"
        )
        if result.output_wav:
            _log.info(f"Output saved: {result.output_wav}")
        _log.info(summary)

        if result.failed > 0:
            messagebox.showwarning(
                "一部失敗",
                "一部の文の読み上げまたは保存に失敗しました。\n"
                f"成功: {result.completed}\n"
                f"失敗: {result.failed}\n"
                f"合計: {result.total_sentences}",
            )

    # -----------------------------------------------------------------
    # Helpers
    # -----------------------------------------------------------------

    def _make_runtime_config(self) -> AppConfig:
        """Merge current UI values into a config for this run."""
        data = self._cfg.model_dump()
        data["tts"]["voice"] = self._settings.selected_voice or ""
        data["tts"]["rate"] = self._settings.rate
        data["tts"]["volume"] = self._settings.volume
        data["tts"]["pitch"] = self._settings.pitch
        data["output"]["play"] = self._settings.play_enabled
        data["output"]["save_wav"] = self._settings.save_enabled
        data["output"]["save_dir"] = str(self._settings.save_dir)
        return AppConfig(**data)


__all__ = ["MainWindow"]
