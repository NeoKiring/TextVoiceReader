from __future__ import annotations

import sys
import types


if "markdown" not in sys.modules:
    markdown_mod = types.ModuleType("markdown")
    markdown_mod.markdown = lambda text, **kwargs: text  # type: ignore[attr-defined]
    sys.modules["markdown"] = markdown_mod


if "bs4" not in sys.modules:
    bs4_mod = types.ModuleType("bs4")

    class _DummySoup:
        def __init__(self, html: str, parser: str) -> None:
            self._html = html

        def find_all(self, tags):
            return []

        def get_text(self, separator: str = "") -> str:
            return self._html

    bs4_mod.BeautifulSoup = _DummySoup  # type: ignore[attr-defined]
    sys.modules["bs4"] = bs4_mod
